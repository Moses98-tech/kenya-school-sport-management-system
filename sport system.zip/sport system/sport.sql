-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2025 at 08:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sport`
--

-- --------------------------------------------------------

--
-- Table structure for table `athletes`
--

CREATE TABLE `athletes` (
  `athlete_id` int(11) NOT NULL,
  `admission_number` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `class` varchar(50) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `school_id` int(11) NOT NULL,
  `sport_category_id` int(11) DEFAULT NULL,
  `playing_position` varchar(50) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `athletes`
--

INSERT INTO `athletes` (`athlete_id`, `admission_number`, `full_name`, `class`, `gender`, `date_of_birth`, `school_id`, `sport_category_id`, `playing_position`, `registration_date`) VALUES
(1, 'NA001', 'John Kamau', 'Form 4A', 'Male', '2007-05-15', 1, 1, 'Forward', '2025-11-07 16:45:27'),
(2, 'NA002', 'Mary Wanjiru', 'Form 3B', 'Female', '2008-08-20', 1, 2, 'Guard', '2025-11-07 16:45:27'),
(3, 'NA003', 'Peter Odhiambo', 'Form 4C', 'Male', '2007-03-10', 1, 1, 'Midfielder', '2025-11-07 16:45:27'),
(4, 'MH001', 'Ahmed Hassan', 'Form 4A', 'Male', '2007-07-12', 2, 1, 'Goalkeeper', '2025-11-07 16:45:27'),
(5, 'MH002', 'Fatuma Ali', 'Form 3A', 'Female', '2008-11-05', 2, 3, 'Spiker', '2025-11-07 16:45:27'),
(6, 'MH003', 'David Kilonzo', 'Form 4B', 'Male', '2007-02-18', 2, 1, 'Defender', '2025-11-07 16:45:27'),
(7, 'KS001', 'Brian Otieno', 'Form 4A', 'Male', '2007-04-22', 3, 1, 'Striker', '2025-11-07 16:45:27'),
(8, 'KS002', 'Grace Akinyi', 'Form 3C', 'Female', '2008-09-14', 3, 2, 'Forward', '2025-11-07 16:45:27'),
(9, 'KS003', 'Samuel Omondi', 'Form 4B', 'Male', '2007-06-30', 3, 1, 'Midfielder', '2025-11-07 16:45:27'),
(10, 'EA001', 'Moses Kipchoge', 'Form 4A', 'Male', '2007-01-25', 4, 1, 'Winger', '2025-11-07 16:45:27'),
(11, 'EA002', 'Ruth Chepkoech', 'Form 3A', 'Female', '2008-12-08', 4, 2, 'Center', '2025-11-07 16:45:27'),
(12, 'NS001', 'Daniel Kariuki', 'Form 4C', 'Male', '2007-10-17', 5, 1, 'Defender', '2025-11-07 16:45:27'),
(13, 'NS002', 'Lucy Njeri', 'Form 3B', 'Female', '2008-07-22', 5, 3, 'Setter', '2025-11-07 16:45:27');

-- --------------------------------------------------------

--
-- Table structure for table `competitions`
--

CREATE TABLE `competitions` (
  `competition_id` int(11) NOT NULL,
  `competition_name` varchar(100) NOT NULL,
  `sport_category_id` int(11) NOT NULL,
  `season` varchar(50) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('upcoming','active','completed') DEFAULT 'upcoming',
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `competitions`
--

INSERT INTO `competitions` (`competition_id`, `competition_name`, `sport_category_id`, `season`, `start_date`, `end_date`, `status`, `description`) VALUES
(1, 'Inter-School Football League 2025', 1, '2025 Spring', '2025-01-15', '2025-05-30', 'active', 'Annual football championship'),
(2, 'Basketball Tournament 2025', 2, '2025 Spring', '2025-02-01', '2025-04-30', 'active', 'Inter-school basketball competition'),
(3, 'Volleyball Championship 2025', 3, '2025 Spring', '2025-03-01', '2025-06-15', 'upcoming', 'Regional volleyball tournament'),
(4, 'Inter-School Football League 2025', 1, '2025 Spring', '2025-01-15', '2025-05-30', 'active', 'Annual football championship'),
(5, 'Basketball Tournament 2025', 2, '2025 Spring', '2025-02-01', '2025-04-30', 'active', 'Inter-school basketball competition'),
(6, 'Volleyball Championship 2025', 3, '2025 Spring', '2025-03-01', '2025-06-15', 'upcoming', 'Regional volleyball tournament'),
(7, 'Inter-School Football League 2025', 1, '2025 Spring', '2025-01-15', '2025-05-30', 'active', 'Annual football championship'),
(8, 'Basketball Tournament 2025', 2, '2025 Spring', '2025-02-01', '2025-04-30', 'active', 'Inter-school basketball competition'),
(9, 'Volleyball Championship 2025', 3, '2025 Spring', '2025-03-01', '2025-06-15', 'upcoming', 'Regional volleyball tournament'),
(10, 'Inter-School Football League 2025', 1, '2025 Spring', '2025-01-15', '2025-05-30', 'active', 'Annual football championship'),
(11, 'Basketball Tournament 2025', 2, '2025 Spring', '2025-02-01', '2025-04-30', 'active', 'Inter-school basketball competition'),
(12, 'Volleyball Championship 2025', 3, '2025 Spring', '2025-03-01', '2025-06-15', 'upcoming', 'Regional volleyball tournament'),
(13, 'Inter-School Football League 2025', 1, '2025 Spring', '2025-11-08', '2025-11-29', 'active', 'Annual football championship'),
(14, 'Inter-School Football League 2025', 1, '2025 Spring', '2025-11-08', '2025-11-29', 'active', 'Annual football championship');

-- --------------------------------------------------------

--
-- Table structure for table `fixtures`
--

CREATE TABLE `fixtures` (
  `fixture_id` int(11) NOT NULL,
  `competition_id` int(11) NOT NULL,
  `home_school_id` int(11) NOT NULL,
  `away_school_id` int(11) NOT NULL,
  `match_date` date DEFAULT NULL,
  `match_time` time DEFAULT NULL,
  `venue` varchar(100) DEFAULT NULL,
  `round` varchar(50) DEFAULT NULL,
  `status` enum('scheduled','completed','postponed') DEFAULT 'scheduled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fixtures`
--

INSERT INTO `fixtures` (`fixture_id`, `competition_id`, `home_school_id`, `away_school_id`, `match_date`, `match_time`, `venue`, `round`, `status`) VALUES
(1, 1, 1, 2, '2025-01-20', '14:00:00', 'Nairobi Academy Stadium', '1', 'completed'),
(2, 1, 3, 4, '2025-01-20', '16:00:00', 'Kisumu Sports Complex', '1', 'completed'),
(3, 1, 5, 1, '2025-01-21', '15:00:00', 'Nakuru Stadium', '1', 'completed'),
(4, 1, 2, 3, '2025-11-15', '14:00:00', 'Mombasa Stadium', '2', 'scheduled'),
(5, 1, 4, 5, '2025-11-15', '16:00:00', 'Eldoret Sports Ground', '2', 'scheduled'),
(6, 1, 1, 3, '2025-11-20', '15:00:00', 'Nairobi Academy Stadium', '2', 'scheduled');

-- --------------------------------------------------------

--
-- Table structure for table `league_standings`
--

CREATE TABLE `league_standings` (
  `standing_id` int(11) NOT NULL,
  `competition_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `matches_played` int(11) DEFAULT 0,
  `wins` int(11) DEFAULT 0,
  `draws` int(11) DEFAULT 0,
  `losses` int(11) DEFAULT 0,
  `goals_for` int(11) DEFAULT 0,
  `goals_against` int(11) DEFAULT 0,
  `goal_difference` int(11) GENERATED ALWAYS AS (`goals_for` - `goals_against`) STORED,
  `total_points` int(11) DEFAULT 0,
  `position` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `league_standings`
--

INSERT INTO `league_standings` (`standing_id`, `competition_id`, `school_id`, `matches_played`, `wins`, `draws`, `losses`, `goals_for`, `goals_against`, `total_points`, `position`) VALUES
(1, 1, 1, 2, 2, 0, 0, 4, 2, 6, 1),
(2, 1, 3, 1, 0, 1, 0, 3, 3, 1, 2),
(3, 1, 4, 1, 0, 1, 0, 3, 3, 1, 3),
(4, 1, 5, 1, 0, 0, 1, 1, 2, 0, 4),
(5, 1, 2, 1, 0, 0, 1, 1, 2, 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `player_statistics`
--

CREATE TABLE `player_statistics` (
  `stat_id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `athlete_id` int(11) NOT NULL,
  `goals_scored` int(11) DEFAULT 0,
  `assists` int(11) DEFAULT 0,
  `yellow_cards` int(11) DEFAULT 0,
  `red_cards` int(11) DEFAULT 0,
  `minutes_played` int(11) DEFAULT 0,
  `performance_rating` decimal(3,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `result_id` int(11) NOT NULL,
  `fixture_id` int(11) NOT NULL,
  `home_score` int(11) DEFAULT 0,
  `away_score` int(11) DEFAULT 0,
  `winner_school_id` int(11) DEFAULT NULL,
  `match_outcome` enum('win','draw','loss') DEFAULT 'draw',
  `home_points` int(11) DEFAULT 0,
  `away_points` int(11) DEFAULT 0,
  `recorded_by` int(11) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `school_id` int(11) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `motto` varchar(150) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `established_date` date DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`school_id`, `school_name`, `motto`, `location`, `contact_phone`, `contact_email`, `established_date`, `status`) VALUES
(1, 'Nairobi Academy', 'Excellence in Sports', 'Nairobi', '+254700000001', 'info@nairobiacademy.ac.ke', '2010-01-15', 'active'),
(2, 'Mombasa High School', 'Sporting Champions', 'Mombasa', '+254700000002', 'sports@mombasahigh.ac.ke', '2008-03-20', 'active'),
(3, 'Kisumu Sports Institute', 'Play to Win', 'Kisumu', '+254700000003', 'contact@kisumusinstitute.ac.ke', '2012-06-10', 'active'),
(4, 'Eldoret Athletics School', 'Sports for Life', 'Eldoret', '+254700000004', 'admin@eldoretath.ac.ke', '2015-09-05', 'active'),
(5, 'Nakuru Sports Center', 'Victory Through Unity', 'Nakuru', '+254700000005', 'info@nakurusports.ac.ke', '2011-02-28', 'active'),
(6, 'Nairobi Academy', 'Excellence in Sports', 'Nairobi', '+254700000001', 'info@nairobiacademy.ac.ke', '2010-01-15', 'active'),
(7, 'Mombasa High School', 'Sporting Champions', 'Mombasa', '+254700000002', 'sports@mombasahigh.ac.ke', '2008-03-20', 'active'),
(8, 'Kisumu Sports Institute', 'Play to Win', 'Kisumu', '+254700000003', 'contact@kisumusinstitute.ac.ke', '2012-06-10', 'active'),
(9, 'Eldoret Athletics School', 'Sports for Life', 'Eldoret', '+254700000004', 'admin@eldoretath.ac.ke', '2015-09-05', 'active'),
(10, 'Nakuru Sports Center', 'Victory Through Unity', 'Nakuru', '+254700000005', 'info@nakurusports.ac.ke', '2011-02-28', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sport_categories`
--

CREATE TABLE `sport_categories` (
  `sport_category_id` int(11) NOT NULL,
  `sport_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `team_size` int(11) DEFAULT NULL,
  `scoring_type` enum('points','goals','time','distance') DEFAULT 'points'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sport_categories`
--

INSERT INTO `sport_categories` (`sport_category_id`, `sport_name`, `description`, `team_size`, `scoring_type`) VALUES
(1, 'Football', 'Association Football', 11, 'goals'),
(2, 'Basketball', 'Basketball', 5, 'points'),
(3, 'Volleyball', 'Volleyball', 6, 'points'),
(4, 'Rugby', 'Rugby Union', 15, 'points');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('Administrator','Coach','Student') NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `role`, `school_id`, `created_at`, `last_login`, `status`) VALUES
(1, 'moses', 'okothmoses13@gmail.com', '1234', 'Administrator', NULL, '2025-11-07 13:55:02', NULL, 'active'),
(3, 'moses1', 'stevemoses678@gmail.com', '$2y$10$p2BqGb5k8c01KQRQde0Iv.oYEisPpYMv448rEKUbDTURbI9Ly5Tqq', 'Administrator', NULL, '2025-11-07 16:41:31', NULL, 'active'),
(4, 'james', 'james@gmail.com', '$2y$10$nrmJlVglDBonqp0q2YUDrekBROky7OB2l7qxzHmgRZT4K03ij8gqO', 'Administrator', NULL, '2025-11-07 16:44:13', NULL, 'active'),
(5, 'admin', 'admin@sportapp.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', NULL, '2025-11-07 16:45:27', NULL, 'active'),
(6, 'coach_nairobi', 'coach@nairobiacademy.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Coach', 1, '2025-11-07 16:45:27', NULL, 'active'),
(7, 'coach_mombasa', 'coach@mombasahigh.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Coach', 2, '2025-11-07 16:45:27', NULL, 'active'),
(8, 'coach_kisumu', 'coach@kisumusinstitute.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Coach', 3, '2025-11-07 16:45:27', NULL, 'active'),
(9, 'coach_eldoret', 'coach@eldoretath.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Coach', 4, '2025-11-07 16:45:27', NULL, 'active'),
(10, 'coach_nakuru', 'coach@nakurusports.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Coach', 5, '2025-11-07 16:45:27', NULL, 'active'),
(11, 'student1', 'student1@nairobiacademy.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Student', 1, '2025-11-07 16:45:27', NULL, 'active'),
(12, 'student2', 'student2@mombasahigh.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Student', 2, '2025-11-07 16:45:27', NULL, 'active'),
(13, 'student3', 'student3@kisumusinstitute.ac.ke', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Student', 3, '2025-11-07 16:45:27', NULL, 'active'),
(26, 'Jatugo', 'jatugo@gmail.com', '$2y$10$Af7E1P7/f8YapgQWbzcAwOvnEc0fhhJzhZC0s3gLSe1Hn7iCZMqmG', 'Coach', 3, '2025-11-07 18:22:08', '2025-11-07 18:30:50', 'active'),
(27, 'maina', 'maina@gmail.com', '$2y$10$e5FGaDDnUahyJWs0iCgOlOd4ZnUAaZfzcCtgHwJlvoB20C3VTAZx.', 'Student', 7, '2025-11-07 19:00:34', '2025-11-07 19:08:32', 'active'),
(28, 'junior', 'junior@gmail.com', '$2y$10$HIiDUxDNMwHGVvbfl80Mq.O.IgkGV4YV3Ihj7pDISfzzRteJG9rZa', 'Administrator', NULL, '2025-11-07 19:09:22', '2025-11-07 19:09:35', 'active'),
(29, 'george', 'george@gmail.com', '$2y$10$gRxMRSfknMDBcAAsLS/5cOBbTBwB5/0VbfXkT6Vg27TV3wnaGU7aa', 'Coach', 1, '2025-11-07 19:27:10', '2025-11-07 19:27:24', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `athletes`
--
ALTER TABLE `athletes`
  ADD PRIMARY KEY (`athlete_id`),
  ADD UNIQUE KEY `admission_number` (`admission_number`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `sport_category_id` (`sport_category_id`);

--
-- Indexes for table `competitions`
--
ALTER TABLE `competitions`
  ADD PRIMARY KEY (`competition_id`),
  ADD KEY `sport_category_id` (`sport_category_id`);

--
-- Indexes for table `fixtures`
--
ALTER TABLE `fixtures`
  ADD PRIMARY KEY (`fixture_id`),
  ADD KEY `competition_id` (`competition_id`),
  ADD KEY `home_school_id` (`home_school_id`),
  ADD KEY `away_school_id` (`away_school_id`);

--
-- Indexes for table `league_standings`
--
ALTER TABLE `league_standings`
  ADD PRIMARY KEY (`standing_id`),
  ADD KEY `competition_id` (`competition_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `player_statistics`
--
ALTER TABLE `player_statistics`
  ADD PRIMARY KEY (`stat_id`),
  ADD KEY `result_id` (`result_id`),
  ADD KEY `athlete_id` (`athlete_id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `fixture_id` (`fixture_id`),
  ADD KEY `winner_school_id` (`winner_school_id`),
  ADD KEY `recorded_by` (`recorded_by`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `sport_categories`
--
ALTER TABLE `sport_categories`
  ADD PRIMARY KEY (`sport_category_id`),
  ADD UNIQUE KEY `sport_name` (`sport_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `school_id` (`school_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `athletes`
--
ALTER TABLE `athletes`
  MODIFY `athlete_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `competitions`
--
ALTER TABLE `competitions`
  MODIFY `competition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `fixtures`
--
ALTER TABLE `fixtures`
  MODIFY `fixture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `league_standings`
--
ALTER TABLE `league_standings`
  MODIFY `standing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `player_statistics`
--
ALTER TABLE `player_statistics`
  MODIFY `stat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sport_categories`
--
ALTER TABLE `sport_categories`
  MODIFY `sport_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `athletes`
--
ALTER TABLE `athletes`
  ADD CONSTRAINT `athletes_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `athletes_ibfk_2` FOREIGN KEY (`sport_category_id`) REFERENCES `sport_categories` (`sport_category_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `competitions`
--
ALTER TABLE `competitions`
  ADD CONSTRAINT `competitions_ibfk_1` FOREIGN KEY (`sport_category_id`) REFERENCES `sport_categories` (`sport_category_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `fixtures`
--
ALTER TABLE `fixtures`
  ADD CONSTRAINT `fixtures_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`competition_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fixtures_ibfk_2` FOREIGN KEY (`home_school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fixtures_ibfk_3` FOREIGN KEY (`away_school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `league_standings`
--
ALTER TABLE `league_standings`
  ADD CONSTRAINT `league_standings_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `competitions` (`competition_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `league_standings_ibfk_2` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `player_statistics`
--
ALTER TABLE `player_statistics`
  ADD CONSTRAINT `player_statistics_ibfk_1` FOREIGN KEY (`result_id`) REFERENCES `results` (`result_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `player_statistics_ibfk_2` FOREIGN KEY (`athlete_id`) REFERENCES `athletes` (`athlete_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `results`
--
ALTER TABLE `results`
  ADD CONSTRAINT `results_ibfk_1` FOREIGN KEY (`fixture_id`) REFERENCES `fixtures` (`fixture_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `results_ibfk_2` FOREIGN KEY (`winner_school_id`) REFERENCES `schools` (`school_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `results_ibfk_3` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
