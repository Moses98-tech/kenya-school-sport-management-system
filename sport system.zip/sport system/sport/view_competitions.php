<?php
session_start();
require_once "db_connect.php";

// Fetch competitions
$competitions = $conn->query("SELECT c.*, sc.sport_name FROM competitions c LEFT JOIN sport_categories sc ON c.sport_category_id=sc.sport_category_id ORDER BY c.start_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Competitions</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Competitions</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Dashboard</a>

<div class="card shadow">
<div class="card-header bg-info text-white">Competition List</div>
<div class="card-body table-responsive">
<table class="table table-striped">
<thead><tr><th>Name</th><th>Sport</th><th>Season</th><th>Start</th><th>End</th><th>Status</th></tr></thead>
<tbody>
<?php while($comp=$competitions->fetch_assoc()): ?>
<tr>
<td><?= htmlspecialchars($comp['competition_name']) ?></td>
<td><?= htmlspecialchars($comp['sport_name']) ?></td>
<td><?= htmlspecialchars($comp['season']) ?></td>
<td><?= $comp['start_date'] ?></td>
<td><?= $comp['end_date'] ?></td>
<td>
<span class="badge <?= $comp['status']=='active'?'bg-success':($comp['status']=='upcoming'?'bg-warning':'bg-secondary') ?>">
<?= ucfirst($comp['status']) ?>
</span>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</body>
</html>
