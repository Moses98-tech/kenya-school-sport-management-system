<?php
require_once 'db_connect.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fixtures</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fffdd0; /* cream background */
            min-height: 100vh;
            padding-top: 20px;
        }
        h2, h3 {
            color: #333;
        }
        .card {
            margin-bottom: 20px;
        }
        .table thead {
            background-color: #f2e6d9;
        }
        @media (max-width: 576px) {
            .btn-group {
                flex-direction: column;
            }
            .btn-group .btn {
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-3">
        <h2>Fixtures</h2>
        <div class="btn-group">
            <a href="admin_dashboard.php" class="btn btn-outline-secondary btn-sm">← Dashboard</a>
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
        </div>
    </div>
    <hr>

    <!-- Add Fixture Form -->
    <div class="card">
        <div class="card-header bg-light">
            <h5>Add New Fixture</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Competition ID</label>
                        <input type="number" name="competition_id" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Home School ID</label>
                        <input type="number" name="home_school_id" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Away School ID</label>
                        <input type="number" name="away_school_id" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Match Date</label>
                        <input type="date" name="match_date" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Match Time</label>
                        <input type="time" name="match_time" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Venue</label>
                        <input type="text" name="venue" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Round</label>
                        <input type="text" name="round" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="scheduled" selected>Scheduled</option>
                            <option value="inplay">In Play</option>
                            <option value="completed">Completed</option>
                            <option value="postponed">Postponed</option>
                        </select>
                    </div>
                </div>
                <button type="submit" name="add" class="btn btn-primary mt-3">Add Fixture</button>
            </form>
        </div>
    </div>

<?php
// Add fixture
if (isset($_POST['add'])) {
    $stmt = $conn->prepare("INSERT INTO fixtures 
        (competition_id, home_school_id, away_school_id, match_date, match_time, venue, round, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "iiiissss",
        $_POST['competition_id'],
        $_POST['home_school_id'],
        $_POST['away_school_id'],
        $_POST['match_date'],
        $_POST['match_time'],
        $_POST['venue'],
        $_POST['round'],
        $_POST['status']
    );

    if ($stmt->execute()) {
        echo '<div class="alert alert-success mt-3">✅ Fixture added successfully!</div>';
    } else {
        echo '<div class="alert alert-danger mt-3">❌ Error: ' . $stmt->error . '</div>';
    }

    $stmt->close();
}

// Display last 5 fixtures
$result = $conn->query("SELECT * FROM fixtures ORDER BY fixture_id DESC LIMIT 5");

function statusBadge($status) {
    switch ($status) {
        case 'scheduled':
            return '<span class="badge bg-secondary">Scheduled</span>';
        case 'inplay':
            return '<span class="badge bg-success">In Play</span>';
        case 'completed':
            return '<span class="badge bg-primary">Completed</span>';
        case 'postponed':
            return '<span class="badge bg-warning text-dark">Postponed</span>';
        default:
            return '<span class="badge bg-secondary">Unknown</span>';
    }
}

if ($result->num_rows > 0) {
    echo '<h3 class="mt-4">Last 5 Fixtures Added</h3>';
    echo '<div class="table-responsive">';
    echo '<table class="table table-striped table-bordered">';
    echo '<thead>
            <tr>
                <th>Fixture ID</th>
                <th>Competition ID</th>
                <th>Home School ID</th>
                <th>Away School ID</th>
                <th>Match Date</th>
                <th>Match Time</th>
                <th>Venue</th>
                <th>Round</th>
                <th>Status</th>
            </tr>
          </thead>';
    echo '<tbody>';
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
            <td>'.$row['fixture_id'].'</td>
            <td>'.$row['competition_id'].'</td>
            <td>'.$row['home_school_id'].'</td>
            <td>'.$row['away_school_id'].'</td>
            <td>'.$row['match_date'].'</td>
            <td>'.$row['match_time'].'</td>
            <td>'.$row['venue'].'</td>
            <td>'.$row['round'].'</td>
            <td>'.statusBadge($row['status']).'</td>
        </tr>';
    }
    echo '</tbody></table></div>';
} else {
    echo '<div class="alert alert-warning mt-3">No fixtures found.</div>';
}
?>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
