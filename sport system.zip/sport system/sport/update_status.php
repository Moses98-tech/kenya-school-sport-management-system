<?php
require_once "db_connect.php";

// Update competitions
$conn->query("UPDATE competitions SET status='active' WHERE start_date <= CURDATE() AND status='upcoming'");
$conn->query("UPDATE competitions SET status='completed' WHERE end_date < CURDATE() AND status != 'completed'");

// Update fixtures
$conn->query("UPDATE fixtures SET status='inplay' WHERE match_date = CURDATE() AND match_time <= CURTIME() AND status='scheduled'");
$conn->query("UPDATE fixtures SET status='completed' WHERE match_date < CURDATE() AND status != 'completed'");
echo "Statuses updated successfully.";
