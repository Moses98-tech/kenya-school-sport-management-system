<?php
session_start();
if ($_SESSION['role'] != 'Coach') {
    header("Location: login.php");
    exit;
}
require_once 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Athlete Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container my-4">
  <h2>Athlete Management</h2>
  <a href="coach_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

  <!-- Add Athlete Form -->
  <div class="card mb-4 shadow">
    <div class="card-header bg-primary text-white">Register New Athlete</div>
    <div class="card-body">
      <form method="POST" action="">
        <div class="row mb-2">
          <div class="col-md-6">
            <input type="text" name="full_name" class="form-control" placeholder="Full Name" required>
          </div>
          <div class="col-md-6">
            <input type="text" name="admission_number" class="form-control" placeholder="Admission Number" required>
          </div>
        </div>
        <div class="row mb-2">
          <div class="col-md-4">
            <input type="text" name="class" class="form-control" placeholder="Class" required>
          </div>
          <div class="col-md-4">
            <select name="gender" class="form-control" required>
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div class="col-md-4">
            <input type="date" name="dob" class="form-control" placeholder="Date of Birth" required>
          </div>
        </div>
        <button type="submit" name="add_athlete" class="btn btn-success">Add Athlete</button>
      </form>
    </div>
  </div>

  <!-- Display Athletes -->
  <div class="card shadow">
    <div class="card-header bg-primary text-white">Registered Athletes</div>
    <div class="card-body">
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Admission No</th>
            <th>Class</th>
            <th>Gender</th>
            <th>DOB</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM athletes WHERE school_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $_SESSION['school_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['athlete_id']}</td>
                <td>{$row['full_name']}</td>
                <td>{$row['admission_number']}</td>
                <td>{$row['class']}</td>
                <td>{$row['gender']}</td>
                <td>{$row['date_of_birth']}</td>
            </tr>";
        }
        ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>
