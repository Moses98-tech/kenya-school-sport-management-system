<?php
require_once 'db_connect.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Competitions</title>
    <style>
        /* Cream background for the page */
        body {
            background-color: #fffdd0; /* Cream */
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h2, h3 {
            color: #333;
        }

        a {
            text-decoration: none;
            color: #333;
            margin-right: 10px;
        }

        a:hover {
            text-decoration: underline;
        }

        hr {
            margin: 20px 0;
            border: 0;
            border-top: 1px solid #ccc;
        }

        /* Form styling */
        form {
            background-color: #fdf5e6; /* slightly lighter cream for form */
            padding: 15px;
            border-radius: 8px;
            max-width: 600px;
        }

        input, textarea, button {
            display: block;
            width: 95%;
            padding: 8px;
            margin: 10px 0;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        textarea {
            resize: vertical;
        }

        button {
            width: auto;
            background-color: #f2e6d9;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background-color: #e6d9c7;
        }

        /* Table styling */
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
        }

        table th, table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #f2e6d9;
        }

        table tr:nth-child(even) {
            background-color: #fdf5e6;
        }

        p {
            font-weight: bold;
        }
    </style>
</head>
<body>
<h2>Competitions</h2>

<a href="admin_dashboard.php">← Back to Dashboard</a> | 
<a href="logout.php">Logout</a>
<hr>

<h3>Add New Competition</h3>
<form method="POST" action="">
    <input type="text" name="competition_name" placeholder="Competition Name" required>
    <input type="number" name="sport_category_id" placeholder="Sport Category ID" required>
    <input type="text" name="season" placeholder="Season" required>
    <input type="date" name="start_date" required>
    <input type="date" name="end_date" required>
    <input type="text" name="status" placeholder="Status" value="active">
    <textarea name="description" placeholder="Description"></textarea>
    <button type="submit" name="add">Add Competition</button>
</form>

<?php
if (isset($_POST['add'])) {
    // Trim inputs
    $competition_name = trim($_POST['competition_name'] ?? '');
    $sport_category_id = trim($_POST['sport_category_id'] ?? '');
    $season = trim($_POST['season'] ?? '');
    $start_date = trim($_POST['start_date'] ?? '');
    $end_date = trim($_POST['end_date'] ?? '');
    $status = trim($_POST['status'] ?? 'active');
    $description = trim($_POST['description'] ?? '');

    // Validate required fields
    if ($competition_name === '' || $sport_category_id === '' || $season === '' || $start_date === '' || $end_date === '') {
        echo "<p>❌ Please fill in all required fields.</p>";
    } else {
        // Insert safely
        $stmt = $conn->prepare("INSERT INTO competitions 
            (competition_name, sport_category_id, season, start_date, end_date, status, description) 
            VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "sisssss",
            $competition_name,
            $sport_category_id,
            $season,
            $start_date,
            $end_date,
            $status,
            $description
        );

        if ($stmt->execute()) {
            echo "<p>✅ Competition added successfully!</p>";
        } else {
            echo "<p>❌ Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
    }
}

// Display last 3 competitions
$result = $conn->query("SELECT * FROM competitions ORDER BY competition_id DESC LIMIT 3");

if ($result->num_rows > 0) {
    echo "<h3>Last 3 Competitions Added</h3>";
    echo "<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Sport Category ID</th>
        <th>Season</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Status</th>
        <th>Description</th>
    </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['competition_id']}</td>
            <td>{$row['competition_name']}</td>
            <td>{$row['sport_category_id']}</td>
            <td>{$row['season']}</td>
            <td>{$row['start_date']}</td>
            <td>{$row['end_date']}</td>
            <td>{$row['status']}</td>
            <td>{$row['description']}</td>
        </tr>";
    }

    echo "</table>";
} else {
    echo "<p>No competitions found.</p>";
}
?>
</body>
</html>
