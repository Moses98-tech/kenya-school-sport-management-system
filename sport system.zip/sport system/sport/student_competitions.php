<?php
session_start();
if($_SESSION['role'] != 'Student'){
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

$athlete_id = $_SESSION['athlete_id'] ?? 0;

// Competitions joined
$competitions = $conn->query("
    SELECT DISTINCT c.*, sc.sport_name
    FROM competitions c
    JOIN fixtures f ON c.competition_id = f.competition_id
    JOIN athletes a ON a.school_id = f.home_school_id OR a.school_id = f.away_school_id
    JOIN sport_categories sc ON c.sport_category_id = sc.sport_category_id
    WHERE a.athlete_id = $athlete_id
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Competitions</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>My Competitions</h2>
<?php if($competitions->num_rows > 0): ?>
<table class="table table-bordered table-striped">
<thead>
<tr>
<th>Competition</th>
<th>Sport</th>
<th>Season</th>
<th>Start Date</th>
<th>End Date</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php while($row = $competitions->fetch_assoc()): ?>
<tr>
<td><?php echo $row['competition_name']; ?></td>
<td><?php echo $row['sport_name']; ?></td>
<td><?php echo $row['season']; ?></td>
<td><?php echo $row['start_date']; ?></td>
<td><?php echo $row['end_date']; ?></td>
<td><?php echo ucfirst($row['status']); ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p class="alert alert-info">You are not registered in any competitions.</p>
<?php endif; ?>
</div>
</body>
</html>
