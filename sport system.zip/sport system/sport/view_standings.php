<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Fetch all competitions for selection
$competitions = $conn->query("SELECT * FROM competitions WHERE status='active'");
$selected_competition_id = $_GET['competition_id'] ?? null;

$standings = [];
if($selected_competition_id){
    $standings = $conn->query("SELECT ls.*, s.school_name FROM league_standings ls LEFT JOIN schools s ON ls.school_id=s.school_id WHERE ls.competition_id='$selected_competition_id' ORDER BY ls.position ASC");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>League Standings</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>League Standings</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<form class="row g-2 mb-3" method="GET">
<div class="col-md-4">
<select name="competition_id" class="form-control" required>
<option value="">Select Competition</option>
<?php while($c=$competitions->fetch_assoc()){ 
$selected = ($c['competition_id']==$selected_competition_id)?'selected':''; 
echo "<option value='{$c['competition_id']}' $selected>{$c['competition_name']}</option>";
} ?>
</select>
</div>
<div class="col-md-2"><button class="btn btn-success">View Standings</button></div>
</form>

<?php if($standings && $standings->num_rows>0): ?>
<table class="table table-striped table-hover">
<thead>
<tr>
<th>Position</th><th>School</th><th>Played</th><th>Wins</th><th>Draws</th><th>Losses</th><th>GF</th><th>GA</th><th>GD</th><th>Points</th>
</tr>
</thead>
<tbody>
<?php while($s=$standings->fetch_assoc()): ?>
<tr>
<td><?= $s['position'] ?></td>
<td><?= htmlspecialchars($s['school_name']) ?></td>
<td><?= $s['matches_played'] ?></td>
<td><?= $s['wins'] ?></td>
<td><?= $s['draws'] ?></td>
<td><?= $s['losses'] ?></td>
<td><?= $s['goals_for'] ?></td>
<td><?= $s['goals_against'] ?></td>
<td><?= $s['goal_difference'] ?></td>
<td><?= $s['total_points'] ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<div class="alert alert-warning">Select a competition to view standings.</div>
<?php endif; ?>
</div>
</body>
</html>
