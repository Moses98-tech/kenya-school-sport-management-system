<?php
function status_badge($status){
    return match($status){
        'active' => '<span class="badge bg-success">Active</span>',
        'upcoming' => '<span class="badge bg-warning text-dark">Upcoming</span>',
        'completed' => '<span class="badge bg-secondary">Completed</span>',
        'scheduled' => '<span class="badge bg-info text-dark">Scheduled</span>',
        'postponed' => '<span class="badge bg-danger">Postponed</span>',
        default => '<span class="badge bg-light text-dark">Unknown</span>'
    };
}
