<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Generate a simple report
$results = $conn->query("SELECT r.*, f.competition_id, f.home_school_id, f.away_school_id, hs.school_name AS home_team, asch.school_name AS away_team, c.competition_name 
FROM results r 
LEFT JOIN fixtures f ON r.fixture_id=f.fixture_id
LEFT JOIN schools hs ON f.home_school_id=hs.school_id
LEFT JOIN schools asch ON f.away_school_id=asch.school_id
LEFT JOIN competitions c ON f.competition_id=c.competition_id
ORDER BY r.recorded_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Reports</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Reports</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>
<div class="card shadow">
<div class="card-header bg-primary text-white">Match Results Report</div>
<div class="card-body table-responsive">
<table class="table table-striped table-hover">
<thead>
<tr>
<th>Date</th><th>Competition</th><th>Home Team</th><th>Away Team</th><th>Score</th><th>Winner</th>
</tr>
</thead>
<tbody>
<?php while($r=$results->fetch_assoc()): ?>
<tr>
<td><?= $r['recorded_at'] ?></td>
<td><?= htmlspecialchars($r['competition_name']) ?></td>
<td><?= htmlspecialchars($r['home_team']) ?></td>
<td><?= htmlspecialchars($r['away_team']) ?></td>
<td><?= $r['home_score'] ?> - <?= $r['away_score'] ?></td>
<td><?= $r['winner_school_id'] ? ($r['winner_school_id']==$r['home_school_id']?$r['home_team']:$r['away_team']):'Draw' ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</body>
</html>
