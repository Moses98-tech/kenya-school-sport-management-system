<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Add School
if(isset($_POST['add_school'])){
    $name = $_POST['school_name'];
    $motto = $_POST['motto'];
    $location = $_POST['location'];
    $email = $_POST['contact_email'];
    $phone = $_POST['contact_phone'];

    $stmt = $conn->prepare("INSERT INTO schools (school_name,motto,location,contact_email,contact_phone,status,established_date) VALUES (?,?,?,?,?, 'active', NOW())");
    $stmt->bind_param("sssss",$name,$motto,$location,$email,$phone);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_schools.php");
    exit;
}

$schools = $conn->query("SELECT * FROM schools ORDER BY school_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Schools</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Manage Schools</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<!-- Add School Form -->
<div class="card shadow mb-4">
  <div class="card-header bg-success text-white">Add New School</div>
  <div class="card-body">
    <form method="POST">
      <div class="row g-2">
        <div class="col-md-4">
          <input type="text" name="school_name" class="form-control" placeholder="School Name" required>
        </div>
        <div class="col-md-4">
          <input type="text" name="motto" class="form-control" placeholder="Motto">
        </div>
        <div class="col-md-4">
          <input type="text" name="location" class="form-control" placeholder="Location">
        </div>
      </div>
      <div class="row g-2 mt-2">
        <div class="col-md-4">
          <input type="email" name="contact_email" class="form-control" placeholder="Contact Email">
        </div>
        <div class="col-md-4">
          <input type="text" name="contact_phone" class="form-control" placeholder="Contact Phone">
        </div>
        <div class="col-md-4">
          <button type="submit" name="add_school" class="btn btn-success">Add School</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Schools Table -->
<div class="card shadow">
  <div class="card-header bg-success text-white">Registered Schools</div>
  <div class="card-body table-responsive">
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Motto</th>
          <th>Location</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php while($s = $schools->fetch_assoc()): ?>
        <tr>
          <td><?= $s['school_id'] ?></td>
          <td><?= htmlspecialchars($s['school_name']) ?></td>
          <td><?= htmlspecialchars($s['motto']) ?></td>
          <td><?= htmlspecialchars($s['location']) ?></td>
          <td><?= htmlspecialchars($s['contact_email']) ?></td>
          <td><?= htmlspecialchars($s['contact_phone']) ?></td>
          <td><?= $s['status'] ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
</div>
</body>
</html>
