<?php
session_start();
if ($_SESSION['role'] != 'Coach') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

$message = "";

if(isset($_POST['register'])) {
    $stmt = $conn->prepare("INSERT INTO athletes 
        (admission_number, full_name, class, gender, date_of_birth, school_id, sport_category_id, playing_position, registration_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssiiii", 
        $_POST['admission_number'],
        $_POST['full_name'],
        $_POST['class'],
        $_POST['gender'],
        $_POST['dob'],
        $_SESSION['school_id'],
        $_POST['sport_category_id'],
        $_POST['playing_position']
    );
    if($stmt->execute()){
        $message = "✅ Athlete registered successfully!";
    } else {
        $message = "❌ Error: ".$stmt->error;
    }
    $stmt->close();
}

// Fetch sports categories
$sports = $conn->query("SELECT * FROM sport_categories");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register Athlete</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>Register Athlete</h2>
<?php if($message) echo "<div class='alert alert-info'>$message</div>"; ?>
<form method="POST">
    <input type="text" name="admission_number" placeholder="Admission Number" class="form-control mb-2" required>
    <input type="text" name="full_name" placeholder="Full Name" class="form-control mb-2" required>
    <input type="text" name="class" placeholder="Class" class="form-control mb-2" required>
    <select name="gender" class="form-control mb-2" required>
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </select>
    <input type="date" name="dob" class="form-control mb-2" required>
    <select name="sport_category_id" class="form-control mb-2" required>
        <option value="">Select Sport</option>
        <?php while($row = $sports->fetch_assoc()): ?>
        <option value="<?php echo $row['sport_category_id']; ?>"><?php echo $row['sport_name']; ?></option>
        <?php endwhile; ?>
    </select>
    <input type="text" name="playing_position" placeholder="Position" class="form-control mb-2">
    <button type="submit" name="register" class="btn btn-success">Register Athlete</button>
</form>
</div>
</body>
</html>
