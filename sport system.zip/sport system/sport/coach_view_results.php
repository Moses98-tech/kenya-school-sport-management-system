<?php
session_start();
if($_SESSION['role'] != 'Coach'){
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Fetch results for coach's school
$results = $conn->query("
    SELECT r.*, f.home_school_id, f.away_school_id, f.match_date, f.match_time 
    FROM results r 
    JOIN fixtures f ON r.fixture_id = f.fixture_id
    WHERE f.home_school_id={$_SESSION['school_id']} OR f.away_school_id={$_SESSION['school_id']}
    ORDER BY f.match_date DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Results</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>Match Results</h2>
<?php if($results->num_rows > 0): ?>
<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>Fixture ID</th>
            <th>Home Score</th>
            <th>Away Score</th>
            <th>Winner</th>
            <th>Date</th>
            <th>Time</th>
        </tr>
    </thead>
    <tbody>
    <?php while($row = $results->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['fixture_id']; ?></td>
            <td><?php echo $row['home_score']; ?></td>
            <td><?php echo $row['away_score']; ?></td>
            <td><?php echo $row['winner_school_id'] ?? "Draw"; ?></td>
            <td><?php echo $row['match_date']; ?></td>
            <td><?php echo $row['match_time']; ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
<?php else: ?>
<p class="alert alert-info">No results recorded yet.</p>
<?php endif; ?>
</div>
</body>
</html>
