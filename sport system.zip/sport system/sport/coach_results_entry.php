<?php
session_start();
if ($_SESSION['role'] != 'Coach') {
    header("Location: login.php");
    exit;
}
require_once 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Record Results</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
  <h2>Record Match Results</h2>
  <a href="coach_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

  <!-- Results Entry Form -->
  <div class="card shadow">
    <div class="card-body">
      <form method="POST" action="process_results.php">
        <div class="mb-3">
          <label>Fixture ID</label>
          <input type="number" name="fixture_id" class="form-control" required>
        </div>
        <div class="row mb-3">
          <div class="col-md-6">
            <label>Home Score</label>
            <input type="number" name="home_score" class="form-control" required>
          </div>
          <div class="col-md-6">
            <label>Away Score</label>
            <input type="number" name="away_score" class="form-control" required>
          </div>
        </div>
        <div class="mb-3">
          <label>Notes</label>
          <textarea name="notes" class="form-control"></textarea>
        </div>
        <button type="submit" name="record_result" class="btn btn-success">Record Result</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
