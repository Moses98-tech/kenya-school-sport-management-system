<header class="main-header">
    <div class="header-left">
        <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
        <h1 class="header-logo">🏆 Sports Management</h1>
    </div>
    <div class="header-right">
        <div class="user-info">
            <span class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <span class="user-role"><?php echo ucfirst($_SESSION['role']); ?></span>
        </div>
        <a href="logout.php" class="btn-logout">Logout</a>
    </div>
</header>