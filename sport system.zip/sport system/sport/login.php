<?php
session_start();
require_once "db_connect.php";

// Redirect already logged-in users
if (isset($_SESSION['role'])) {
    switch ($_SESSION['role']) {
        case 'Coach':
            header("Location: coach_dashboard.php");
            exit;
        case 'Administrator':
            header("Location: dashboard_admin.php");
            exit;
        case 'Student':
            header("Location: dashboard_student.php");
            exit;
    }
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("SELECT user_id, username, password_hash, role, school_id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password_hash'])) {
                // ✅ Store session data
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['school_id'] = $user['school_id'];

                // ✅ Update last login
                $update = $conn->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
                $update->bind_param("i", $user['user_id']);
                $update->execute();

                // ✅ Handle cookies (Remember Me)
                if ($remember) {
                    setcookie("remember_username", $username, time() + (86400 * 30), "/"); // 30 days
                } else {
                    setcookie("remember_username", "", time() - 3600, "/");
                }

                // ✅ Redirect based on role
                switch ($user['role']) {
                    case 'Coach':
                        header("Location: coach_dashboard.php");
                        break;
                    case 'Administrator':
                        header("Location: dashboard_admin.php");
                        break;
                    case 'Student':
                        header("Location: dashboard_student.php");
                        break;
                    default:
                        $error = "Unknown user role.";
                }
                exit;
            } else {
                $error = "❌ Invalid username or password.";
            }
        } else {
            $error = "❌ Invalid username or password.";
        }
    } else {
        $error = "⚠️ Please enter both username and password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Sport System</title>
    <style>
        body {
            font-family: "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #2b5876, #4e4376);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: white;
            padding: 35px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
            width: 370px;
            text-align: center;
        }
        h2 {
            color: #333;
            margin-bottom: 25px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
        }
        label {
            font-size: 14px;
            color: #444;
            float: left;
        }
        button {
            width: 100%;
            background: #4e4376;
            color: white;
            padding: 10px 12px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #2b5876;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
        .remember {
            text-align: left;
            margin: 10px 0;
        }
        .links {
            margin-top: 15px;
        }
        .links a {
            text-decoration: none;
            color: #4e4376;
            font-size: 14px;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Sport System Login</h2>

        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <label>Username</label>
            <input type="text" id="username" name="username" placeholder="Enter Username" required>

            <label>Password</label>
            <input type="password" name="password" placeholder="Enter Password" required>

            <div class="remember">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">Remember Me</label>
            </div>

            <button type="submit">Login</button>
        </form>

        <div class="links">
            <p>Don't have an account? <a href="registration.php">Register here</a></p>
        </div>
    </div>

    <script>
        // ✅ JavaScript Cookie Auto-fill (client-side memory)
        document.addEventListener("DOMContentLoaded", function () {
            const usernameField = document.getElementById("username");
            const rememberCheckbox = document.getElementById("remember");

            // Load username from cookie
            const rememberedUser = getCookie("remember_username");
            if (rememberedUser) {
                usernameField.value = rememberedUser;
                rememberCheckbox.checked = true;
            }

            // When form is submitted, save or remove cookie
            document.querySelector("form").addEventListener("submit", function () {
                if (rememberCheckbox.checked) {
                    setCookie("remember_username", usernameField.value, 30);
                } else {
                    deleteCookie("remember_username");
                }
            });
        });

        // Helper functions for cookies
        function setCookie(name, value, days) {
            const d = new Date();
            d.setTime(d.getTime() + (days*24*60*60*1000));
            document.cookie = name + "=" + value + ";expires=" + d.toUTCString() + ";path=/";
        }
        function getCookie(name) {
            const cname = name + "=";
            const decodedCookie = decodeURIComponent(document.cookie);
            const ca = decodedCookie.split(';');
            for(let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) === ' ') c = c.substring(1);
                if (c.indexOf(cname) === 0) return c.substring(cname.length, c.length);
            }
            return "";
        }
        function deleteCookie(name) {
            document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        }
    </script>
</body>
</html>
