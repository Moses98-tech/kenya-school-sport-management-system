<?php
session_start();
require_once "db_connect.php";

// Add Category
if(isset($_POST['add'])){
    $sport_name = $_POST['sport_name'];
    $description = $_POST['description'];
    $team_size = $_POST['team_size'];
    $scoring_type = $_POST['scoring_type'];

    $stmt = $conn->prepare("INSERT INTO sport_categories (sport_name, description, team_size, scoring_type) VALUES (?,?,?,?)");
    $stmt->bind_param("ssis",$sport_name,$description,$team_size,$scoring_type);
    $stmt->execute();
    $stmt->close();
}

// Delete Category
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM sport_categories WHERE sport_category_id=$id");
}

// Fetch all categories
$categories = $conn->query("SELECT * FROM sport_categories");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Sport Categories</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Sport Categories</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Dashboard</a>

<!-- Add Category -->
<div class="card shadow mb-4">
<div class="card-header bg-success text-white">Add New Sport Category</div>
<div class="card-body">
<form method="POST" class="row g-2">
<div class="col-md-3"><input type="text" name="sport_name" placeholder="Sport Name" class="form-control" required></div>
<div class="col-md-4"><input type="text" name="description" placeholder="Description" class="form-control"></div>
<div class="col-md-2"><input type="number" name="team_size" placeholder="Team Size" class="form-control"></div>
<div class="col-md-2"><input type="text" name="scoring_type" placeholder="Scoring Type" class="form-control"></div>
<div class="col-md-1"><button type="submit" name="add" class="btn btn-success w-100">Add</button></div>
</form>
</div>
</div>

<!-- List Categories -->
<div class="card shadow">
<div class="card-header bg-success text-white">Existing Categories</div>
<div class="card-body table-responsive">
<table class="table table-striped">
<thead><tr><th>ID</th><th>Name</th><th>Description</th><th>Team Size</th><th>Scoring</th><th>Action</th></tr></thead>
<tbody>
<?php while($c=$categories->fetch_assoc()): ?>
<tr>
<td><?= $c['sport_category_id'] ?></td>
<td><?= htmlspecialchars($c['sport_name']) ?></td>
<td><?= htmlspecialchars($c['description']) ?></td>
<td><?= $c['team_size'] ?></td>
<td><?= htmlspecialchars($c['scoring_type']) ?></td>
<td><a href="?delete=<?= $c['sport_category_id'] ?>" class="btn btn-danger btn-sm">Delete</a></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</body>
</html>
