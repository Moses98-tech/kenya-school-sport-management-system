<?php
require_once 'db_connect.php';
require_once 'auth.php';
requireLogin();

// Only admin can manage schools
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// CREATE / UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $school_name = $_POST['school_name'];
    $motto = $_POST['motto'] ?? '';
    $location = $_POST['location'] ?? '';
    $contact_phone = $_POST['contact_phone'] ?? '';
    $contact_email = $_POST['contact_email'] ?? '';
    $established_date = $_POST['established_date'] ?? null;
    $status = $_POST['status'] ?? 'active';

    if (!empty($_POST['school_id'])) {
        // Update
        $stmt = $conn->prepare("UPDATE schools SET school_name=?, motto=?, location=?, contact_phone=?, contact_email=?, established_date=?, status=? WHERE school_id=?");
        $stmt->bind_param("sssssssi", $school_name, $motto, $location, $contact_phone, $contact_email, $established_date, $status, $_POST['school_id']);
        $stmt->execute();
        $stmt->close();
    } else {
        // Insert
        $stmt = $conn->prepare("INSERT INTO schools (school_name, motto, location, contact_phone, contact_email, established_date, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $school_name, $motto, $location, $contact_phone, $contact_email, $established_date, $status);
        $stmt->execute();
        $stmt->close();
    }
}

// DELETE
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM schools WHERE school_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Fetch data
$schools = $conn->query("SELECT * FROM schools");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Schools</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2>Schools Management</h2>
    <a href="admin_dashboard.php" class="btn btn-secondary mb-3">Back to Dashboard</a>
    <hr>

    <!-- Add/Edit Form -->
    <form method="POST" class="row g-3 mb-4">
        <input type="hidden" name="school_id" id="school_id">
        <div class="col-md-3"><input type="text" name="school_name" id="school_name" class="form-control" placeholder="School Name" required></div>
        <div class="col-md-3"><input type="text" name="motto" id="motto" class="form-control" placeholder="Motto"></div>
        <div class="col-md-2"><input type="text" name="location" id="location" class="form-control" placeholder="Location"></div>
        <div class="col-md-2"><input type="text" name="contact_phone" id="contact_phone" class="form-control" placeholder="Phone"></div>
        <div class="col-md-2"><input type="email" name="contact_email" id="contact_email" class="form-control" placeholder="Email"></div>
        <div class="col-md-2"><input type="date" name="established_date" id="established_date" class="form-control"></div>
        <div class="col-md-2">
            <select name="status" id="status" class="form-control">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>
        <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Save</button></div>
    </form>

    <!-- Schools Table -->
    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th><th>Name</th><th>Motto</th><th>Location</th><th>Phone</th><th>Email</th><th>Established</th><th>Status</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($s = $schools->fetch_assoc()): ?>
            <tr>
                <td><?= $s['school_id'] ?></td>
                <td><?= htmlspecialchars($s['school_name']) ?></td>
                <td><?= htmlspecialchars($s['motto']) ?></td>
                <td><?= htmlspecialchars($s['location']) ?></td>
                <td><?= htmlspecialchars($s['contact_phone']) ?></td>
                <td><?= htmlspecialchars($s['contact_email']) ?></td>
                <td><?= $s['established_date'] ?></td>
                <td><?= $s['status'] ?></td>
                <td>
                    <a href="#" class="btn btn-warning btn-sm edit-btn"
                       data-id="<?= $s['school_id'] ?>"
                       data-name="<?= htmlspecialchars($s['school_name']) ?>"
                       data-motto="<?= htmlspecialchars($s['motto']) ?>"
                       data-location="<?= htmlspecialchars($s['location']) ?>"
                       data-phone="<?= htmlspecialchars($s['contact_phone']) ?>"
                       data-email="<?= htmlspecialchars($s['contact_email']) ?>"
                       data-date="<?= $s['established_date'] ?>"
                       data-status="<?= $s['status'] ?>"
                    >Edit</a>
                    <a href="?delete=<?= $s['school_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this school?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script>
document.querySelectorAll('.edit-btn').forEach(btn=>{
    btn.addEventListener('click',e=>{
        e.preventDefault();
        document.getElementById('school_id').value=btn.dataset.id;
        document.getElementById('school_name').value=btn.dataset.name;
        document.getElementById('motto').value=btn.dataset.motto;
        document.getElementById('location').value=btn.dataset.location;
        document.getElementById('contact_phone').value=btn.dataset.phone;
        document.getElementById('contact_email').value=btn.dataset.email;
        document.getElementById('established_date').value=btn.dataset.date;
        document.getElementById('status').value=btn.dataset.status;
    });
});
</script>
</body>
</html>
