<?php
session_start();
require_once "db_connect.php";

$competition_id = $_GET['competition_id'] ?? null;

if(!$competition_id){
    die("Competition ID required.");
}

// Fetch competition info
$competition = $conn->query("SELECT * FROM competitions WHERE competition_id=$competition_id")->fetch_assoc();

// Fetch fixtures
$fixtures = $conn->query("SELECT f.*, hs.school_name AS home, asch.school_name AS away FROM fixtures f LEFT JOIN schools hs ON f.home_school_id=hs.school_id LEFT JOIN schools asch ON f.away_school_id=asch.school_id WHERE f.competition_id=$competition_id ORDER BY f.match_date ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Fixtures - <?= htmlspecialchars($competition['competition_name']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Fixtures - <?= htmlspecialchars($competition['competition_name']) ?></h2>
<a href="view_competitions.php" class="btn btn-secondary mb-3">← Back to Competitions</a>

<div class="card shadow">
<div class="card-header bg-primary text-white">Scheduled Fixtures</div>
<div class="card-body table-responsive">
<table class="table table-striped">
<thead><tr><th>Date</th><th>Time</th><th>Home Team</th><th>Away Team</th><th>Venue</th><th>Round</th><th>Status</th></tr></thead>
<tbody>
<?php while($f=$fixtures->fetch_assoc()): ?>
<tr>
<td><?= $f['match_date'] ?></td>
<td><?= $f['match_time'] ?></td>
<td><?= htmlspecialchars($f['home']) ?></td>
<td><?= htmlspecialchars($f['away']) ?></td>
<td><?= htmlspecialchars($f['venue']) ?></td>
<td><?= htmlspecialchars($f['round']) ?></td>
<td>
<span class="badge <?= $f['status']=='scheduled'?'bg-warning':($f['status']=='completed'?'bg-success':'bg-secondary') ?>">
<?= ucfirst($f['status']) ?>
</span>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</body>
</html>
