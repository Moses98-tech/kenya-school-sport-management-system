<?php
session_start();
if($_SESSION['role'] != 'Coach'){
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

$fixtures = $conn->query("
    SELECT f.*, s1.school_name as home_school, s2.school_name as away_school
    FROM fixtures f
    JOIN schools s1 ON f.home_school_id = s1.school_id
    JOIN schools s2 ON f.away_school_id = s2.school_id
    WHERE f.home_school_id={$_SESSION['school_id']} OR f.away_school_id={$_SESSION['school_id']}
    ORDER BY f.match_date ASC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Fixtures</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>Upcoming Fixtures</h2>
<?php if($fixtures->num_rows > 0): ?>
<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>Date</th>
    <th>Time</th>
    <th>Home Team</th>
    <th>Away Team</th>
    <th>Venue</th>
    <th>Round</th>
    <th>Status</th>
</tr>
</thead>
<tbody>
<?php while($row = $fixtures->fetch_assoc()): ?>
<tr>
    <td><?php echo $row['match_date']; ?></td>
    <td><?php echo $row['match_time']; ?></td>
    <td><?php echo $row['home_school']; ?></td>
    <td><?php echo $row['away_school']; ?></td>
    <td><?php echo $row['venue']; ?></td>
    <td><?php echo $row['round']; ?></td>
    <td><?php echo ucfirst($row['status']); ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p class="alert alert-info">No fixtures scheduled.</p>
<?php endif; ?>
</div>
</body>
</html>
