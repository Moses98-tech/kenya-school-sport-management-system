<?php
session_start();
require_once "db_connect.php";

// Restrict access to Administrators
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Administrator') {
    header("Location: login.php");
    exit;
}

// Fetch total users and other summary counts
$totalUsersStmt = $conn->prepare("SELECT COUNT(*) AS total FROM users");
$totalUsersStmt->execute();
$totalUsers = $totalUsersStmt->get_result()->fetch_assoc()['total'] ?? 0;

$totalCoachesStmt = $conn->prepare("SELECT COUNT(*) AS total FROM users WHERE role='Coach'");
$totalCoachesStmt->execute();
$totalCoaches = $totalCoachesStmt->get_result()->fetch_assoc()['total'] ?? 0;

$totalStudentsStmt = $conn->prepare("SELECT COUNT(*) AS total FROM users WHERE role='Student'");
$totalStudentsStmt->execute();
$totalStudents = $totalStudentsStmt->get_result()->fetch_assoc()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<style>
body {
    font-family: "Segoe UI", sans-serif;
    margin: 0;
    padding: 0;
    background: #f2f4f8;
}
header {
    background: #4e4376;
    color: #fff;
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
header h1 { margin: 0; font-size: 24px; }
.logout {
    background: #e74c3c;
    color: #fff;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
}
.logout:hover { background: #c0392b; }

.container {
    width: 90%;
    max-width: 1000px;
    margin: 30px auto;
    background: white;
    border-radius: 12px;
    padding: 20px 25px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.card-container {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
}

.card {
    flex: 1;
    min-width: 200px;
    background: #4e4376;
    color: white;
    padding: 20px;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.card h2 {
    margin: 0;
    font-size: 20px;
}
.card p {
    font-size: 28px;
    margin: 10px 0 0 0;
}
</style>
</head>
<body>
<header>
    <h1>Welcome Administrator <?= htmlspecialchars($_SESSION['username']); ?></h1>
    <a href="logout.php" class="logout">Logout</a>
</header>

<div class="container">
    <div class="card-container">
        <div class="card">
            <h2>Total Users</h2>
            <p><?= $totalUsers; ?></p>
        </div>
        <div class="card">
            <h2>Total Coaches</h2>
            <p><?= $totalCoaches; ?></p>
        </div>
        <div class="card">
            <h2>Total Students</h2>
            <p><?= $totalStudents; ?></p>
        </div>
    </div>

    <h2 style="margin-top: 30px;">Recent Users</h2>
    <table border="1" width="100%" cellpadding="8" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
        </tr>
        <?php
        $recentUsersStmt = $conn->prepare("SELECT user_id, username, email, role, status FROM users ORDER BY user_id DESC LIMIT 10");
        $recentUsersStmt->execute();
        $recentUsers = $recentUsersStmt->get_result();
        while($user = $recentUsers->fetch_assoc()):
        ?>
        <tr>
            <td><?= $user['user_id']; ?></td>
            <td><?= htmlspecialchars($user['username']); ?></td>
            <td><?= htmlspecialchars($user['email']); ?></td>
            <td><?= $user['role']; ?></td>
            <td><?= ucfirst($user['status']); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
