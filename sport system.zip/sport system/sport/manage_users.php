<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Add User
if (isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $school_id = $_POST['school_id'] ?: NULL;

    $stmt = $conn->prepare("INSERT INTO users (username,email,password_hash,role,school_id,status,created_at) VALUES (?,?,?,?,?, 'active', NOW())");
    $stmt->bind_param("sssi", $username, $email, $password, $role, $school_id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_users.php");
    exit;
}

// Fetch users
$users = $conn->query("SELECT u.*, s.school_name FROM users u LEFT JOIN schools s ON u.school_id = s.school_id ORDER BY u.user_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Manage Users</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<!-- Add User Form -->
<div class="card shadow mb-4">
  <div class="card-header bg-primary text-white">Add New User</div>
  <div class="card-body">
    <form method="POST">
      <div class="row g-2">
        <div class="col-md-3">
          <input type="text" name="username" class="form-control" placeholder="Username" required>
        </div>
        <div class="col-md-3">
          <input type="email" name="email" class="form-control" placeholder="Email" required>
        </div>
        <div class="col-md-3">
          <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="col-md-3">
          <select name="role" class="form-control" required>
            <option value="">Select Role</option>
            <option value="Administrator">Administrator</option>
            <option value="Coach">Coach</option>
            <option value="Student">Student</option>
          </select>
        </div>
      </div>
      <div class="row mt-2">
        <div class="col-md-4">
          <select name="school_id" class="form-control">
            <option value="">Select School</option>
            <?php
            $schools = $conn->query("SELECT * FROM schools WHERE status='active'");
            while($s = $schools->fetch_assoc()) {
                echo "<option value='{$s['school_id']}'>{$s['school_name']}</option>";
            }
            ?>
          </select>
        </div>
        <div class="col-md-4">
          <button type="submit" name="add_user" class="btn btn-success">Add User</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Users Table -->
<div class="card shadow">
  <div class="card-header bg-primary text-white">Registered Users</div>
  <div class="card-body table-responsive">
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Email</th>
          <th>Role</th>
          <th>School</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php while($u = $users->fetch_assoc()): ?>
        <tr>
          <td><?= $u['user_id'] ?></td>
          <td><?= htmlspecialchars($u['username']) ?></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td><?= $u['role'] ?></td>
          <td><?= $u['school_name'] ?: '-' ?></td>
          <td><?= $u['status'] ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
</div>
</body>
</html>
