<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Fetch competitions
$competitions = $conn->query("SELECT * FROM competitions ORDER BY start_date DESC");

// Fetch results if competition selected
$selected_results = [];
if(isset($_GET['competition_id'])){
    $competition_id = $_GET['competition_id'];
    $selected_results = $conn->query("
        SELECT r.*, f.home_school_id, f.away_school_id, f.home_score, f.away_score, f.match_date, f.match_time
        FROM results r
        JOIN fixtures f ON r.fixture_id = f.fixture_id
        WHERE f.competition_id = $competition_id
        ORDER BY f.match_date DESC
    ");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Competition Results</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>Competition Results</h2>
<form method="GET" class="mb-3">
    <select name="competition_id" class="form-select" onchange="this.form.submit()">
        <option value="">Select Competition</option>
        <?php while($comp = $competitions->fetch_assoc()): ?>
        <option value="<?php echo $comp['competition_id']; ?>" <?php echo (isset($_GET['competition_id']) && $_GET['competition_id']==$comp['competition_id'])?'selected':''; ?>>
            <?php echo htmlspecialchars($comp['competition_name']); ?>
        </option>
        <?php endwhile; ?>
    </select>
</form>

<?php if($selected_results && $selected_results->num_rows > 0): ?>
<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>Fixture</th>
    <th>Home Score</th>
    <th>Away Score</th>
    <th>Winner</th>
    <th>Date</th>
    <th>Time</th>
</tr>
</thead>
<tbody>
<?php while($row = $selected_results->fetch_assoc()): ?>
<tr>
    <td><?php echo $row['home_school_id']." vs ".$row['away_school_id']; ?></td>
    <td><?php echo $row['home_score']; ?></td>
    <td><?php echo $row['away_score']; ?></td>
    <td><?php echo $row['winner_school_id'] ?? "Draw"; ?></td>
    <td><?php echo $row['match_date']; ?></td>
    <td><?php echo $row['match_time']; ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php elseif(isset($_GET['competition_id'])): ?>
<p class="alert alert-info">No results recorded for this competition.</p>
<?php endif; ?>
</div>
</body>
</html>
