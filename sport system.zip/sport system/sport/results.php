<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Fetch fixtures
$fixtures = $conn->query("SELECT f.*, hs.school_name AS home, asch.school_name AS away, c.competition_name 
FROM fixtures f 
LEFT JOIN schools hs ON f.home_school_id=hs.school_id 
LEFT JOIN schools asch ON f.away_school_id=asch.school_id 
LEFT JOIN competitions c ON f.competition_id=c.competition_id
WHERE f.status='scheduled'");

if(isset($_POST['record_result'])){
    $fixture_id = $_POST['fixture_id'];
    $home_score = $_POST['home_score'];
    $away_score = $_POST['away_score'];
    $winner_school_id = ($home_score>$away_score)? $_POST['home_school_id']: (($away_score>$home_score)? $_POST['away_school_id']: NULL);
    $match_outcome = ($home_score>$away_score)? 'home_win': (($away_score>$home_score)? 'away_win':'draw');

    $stmt = $conn->prepare("INSERT INTO results (fixture_id, home_score, away_score, winner_school_id, match_outcome, home_points, away_points, recorded_by, recorded_at) VALUES (?,?,?,?,?,?,?, ?, NOW())");
    $home_points = ($match_outcome=='home_win')?3:($match_outcome=='draw'?1:0);
    $away_points = ($match_outcome=='away_win')?3:($match_outcome=='draw'?1:0);
    $stmt->bind_param("iiiiiii",$fixture_id,$home_score,$away_score,$winner_school_id,$match_outcome,$home_points,$away_points,$_SESSION['user_id']);
    $stmt->execute();
    $stmt->close();
    $conn->query("UPDATE fixtures SET status='completed' WHERE fixture_id='$fixture_id'");
    header("Location: results.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Record Results</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Record Match Results</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<?php while($f=$fixtures->fetch_assoc()): ?>
<div class="card shadow mb-3">
<div class="card-header bg-success text-white">
<?= $f['competition_name'] ?>: <?= $f['home'] ?> vs <?= $f['away'] ?> (<?= $f['match_date'] ?>)
</div>
<div class="card-body">
<form method="POST" class="row g-2 align-items-end">
<input type="hidden" name="fixture_id" value="<?= $f['fixture_id'] ?>">
<input type="hidden" name="home_school_id" value="<?= $f['home_school_id'] ?>">
<input type="hidden" name="away_school_id" value="<?= $f['away_school_id'] ?>">
<div class="col-md-2"><input type="number" name="home_score" class="form-control" placeholder="Home Score" required></div>
<div class="col-md-2"><input type="number" name="away_score" class="form-control" placeholder="Away Score" required></div>
<div class="col-md-2"><button type="submit" name="record_result" class="btn btn-success">Record Result</button></div>
</form>
</div>
</div>
<?php endwhile; ?>
</div>
</body>
</html>
