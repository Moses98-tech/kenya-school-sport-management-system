<?php
session_start();
if($_SESSION['role'] != 'Administrator'){
    header("Location: login.php");
    exit;
}

require_once "db_connect.php";

// Placeholder: export functionality
$message = "This feature will export data in PDF/Excel format. Use libraries like TCPDF or PhpSpreadsheet.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Export Reports</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>Export Reports</h2>
<div class="alert alert-warning"><?php echo $message; ?></div>
</div>
</body>
</html>
