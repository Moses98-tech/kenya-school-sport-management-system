<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Fetch competitions
$competitions = $conn->query("SELECT * FROM competitions ORDER BY start_date DESC");

if(isset($_GET['competition_id'])){
    $competition_id = $_GET['competition_id'];

    // Clear previous standings
    $conn->query("DELETE FROM league_standings WHERE competition_id = $competition_id");

    // Compute standings
    $results = $conn->query("
        SELECT f.home_school_id, f.away_school_id, r.home_score, r.away_score
        FROM fixtures f
        JOIN results r ON f.fixture_id = r.fixture_id
        WHERE f.competition_id = $competition_id
    ");

    $standings = [];
    while($row = $results->fetch_assoc()){
        $home = $row['home_school_id'];
        $away = $row['away_school_id'];
        $homeScore = $row['home_score'];
        $awayScore = $row['away_score'];

        // Initialize
        foreach([$home, $away] as $team){
            if(!isset($standings[$team])){
                $standings[$team] = [
                    'matches_played'=>0,'wins'=>0,'draws'=>0,'losses'=>0,
                    'goals_for'=>0,'goals_against'=>0,'total_points'=>0
                ];
            }
        }

        $standings[$home]['matches_played']++;
        $standings[$away]['matches_played']++;

        $standings[$home]['goals_for'] += $homeScore;
        $standings[$home]['goals_against'] += $awayScore;
        $standings[$away]['goals_for'] += $awayScore;
        $standings[$away]['goals_against'] += $homeScore;

        if($homeScore > $awayScore){
            $standings[$home]['wins']++;
            $standings[$home]['total_points'] += 3;
            $standings[$away]['losses']++;
        } elseif($homeScore < $awayScore){
            $standings[$away]['wins']++;
            $standings[$away]['total_points'] +=3;
            $standings[$home]['losses']++;
        } else {
            $standings[$home]['draws']++;
            $standings[$away]['draws']++;
            $standings[$home]['total_points']++;
            $standings[$away]['total_points']++;
        }
    }

    // Insert standings
    foreach($standings as $school_id=>$data){
        $goal_diff = $data['goals_for'] - $data['goals_against'];
        $conn->query("
            INSERT INTO league_standings 
            (competition_id, school_id, matches_played, wins, draws, losses, goals_for, goals_against, goal_difference, total_points)
            VALUES ($competition_id, $school_id, {$data['matches_played']}, {$data['wins']}, {$data['draws']}, {$data['losses']}, 
                    {$data['goals_for']}, {$data['goals_against']}, $goal_diff, {$data['total_points']})
        ");
    }

    header("Location: competition_standings.php?competition_id=$competition_id");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Competition Standings</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>Competition Standings</h2>
<form method="GET" class="mb-3">
<select name="competition_id" class="form-select" onchange="this.form.submit()">
    <option value="">Select Competition</option>
    <?php while($comp = $competitions->fetch_assoc()): ?>
        <option value="<?php echo $comp['competition_id']; ?>" <?php echo (isset($_GET['competition_id']) && $_GET['competition_id']==$comp['competition_id'])?'selected':''; ?>>
            <?php echo htmlspecialchars($comp['competition_name']); ?>
        </option>
    <?php endwhile; ?>
</select>
</form>

<?php
if(isset($_GET['competition_id'])){
    $standings = $conn->query("
        SELECT ls.*, s.school_name 
        FROM league_standings ls 
        JOIN schools s ON ls.school_id = s.school_id
        WHERE ls.competition_id = {$_GET['competition_id']}
        ORDER BY ls.total_points DESC, ls.goal_difference DESC
    ");
    if($standings->num_rows > 0):
?>
<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>School</th>
    <th>MP</th>
    <th>W</th>
    <th>D</th>
    <th>L</th>
    <th>GF</th>
    <th>GA</th>
    <th>GD</th>
    <th>Points</th>
</tr>
</thead>
<tbody>
<?php while($row = $standings->fetch_assoc()): ?>
<tr>
    <td><?php echo $row['school_name']; ?></td>
    <td><?php echo $row['matches_played']; ?></td>
    <td><?php echo $row['wins']; ?></td>
    <td><?php echo $row['draws']; ?></td>
    <td><?php echo $row['losses']; ?></td>
    <td><?php echo $row['goals_for']; ?></td>
    <td><?php echo $row['goals_against']; ?></td>
    <td><?php echo $row['goal_difference']; ?></td>
    <td><?php echo $row['total_points']; ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p class="alert alert-info">Standings not yet calculated. Select a competition to calculate.</p>
<?php endif; } ?>
</div>
</body>
</html>
