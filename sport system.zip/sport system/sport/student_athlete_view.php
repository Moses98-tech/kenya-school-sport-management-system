<?php
session_start();
if($_SESSION['role'] != 'Student'){
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

$athlete_id = $_SESSION['athlete_id'] ?? 0;

// Personal stats
$stats = $conn->query("
    SELECT ps.*, f.match_date, a.full_name
    FROM player_statistics ps
    JOIN results r ON ps.result_id = r.result_id
    JOIN fixtures f ON r.fixture_id = f.fixture_id
    JOIN athletes a ON ps.athlete_id = a.athlete_id
    WHERE ps.athlete_id = $athlete_id
    ORDER BY f.match_date DESC
");

// Fixtures
$fixtures = $conn->query("
    SELECT f.*, s1.school_name as home_school, s2.school_name as away_school
    FROM fixtures f
    JOIN schools s1 ON f.home_school_id = s1.school_id
    JOIN schools s2 ON f.away_school_id = s2.school_id
    JOIN athletes a ON a.school_id = f.home_school_id OR a.school_id = f.away_school_id
    WHERE a.athlete_id = $athlete_id
    ORDER BY f.match_date ASC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Performance</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>My Statistics</h2>
<?php if($stats->num_rows > 0): ?>
<table class="table table-bordered table-striped">
<thead>
<tr>
<th>Match Date</th>
<th>Goals</th>
<th>Assists</th>
<th>Yellow</th>
<th>Red</th>
<th>Minutes Played</th>
<th>Rating</th>
</tr>
</thead>
<tbody>
<?php while($row = $stats->fetch_assoc()): ?>
<tr>
<td><?php echo $row['match_date']; ?></td>
<td><?php echo $row['goals_scored']; ?></td>
<td><?php echo $row['assists']; ?></td>
<td><?php echo $row['yellow_cards']; ?></td>
<td><?php echo $row['red_cards']; ?></td>
<td><?php echo $row['minutes_played']; ?></td>
<td><?php echo $row['performance_rating']; ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p class="alert alert-info">No statistics available.</p>
<?php endif; ?>

<h2>My Fixtures</h2>
<?php if($fixtures->num_rows > 0): ?>
<table class="table table-bordered table-striped">
<thead>
<tr>
<th>Date</th>
<th>Time</th>
<th>Home</th>
<th>Away</th>
<th>Venue</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<?php while($row = $fixtures->fetch_assoc()): ?>
<tr>
<td><?php echo $row['match_date']; ?></td>
<td><?php echo $row['match_time']; ?></td>
<td><?php echo $row['home_school']; ?></td>
<td><?php echo $row['away_school']; ?></td>
<td><?php echo $row['venue']; ?></td>
<td><?php echo ucfirst($row['status']); ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p class="alert alert-info">No upcoming fixtures.</p>
<?php endif; ?>
</div>
</body>
</html>
