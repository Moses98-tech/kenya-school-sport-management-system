<?php
session_start();
require_once "db_connect.php";

// ✅ Restrict access to coaches only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Coach') {
    header("Location: login.php");
    exit;
}

$schoolId = $_SESSION['school_id'];

// ✅ Fetch total athletes count
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM users WHERE school_id = ? AND role = 'Student'");
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$totalResult = $stmt->get_result()->fetch_assoc();
$totalAthletes = $totalResult['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coach Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* General UI */
        body {
            font-family: "Segoe UI", Roboto, sans-serif;
            background: #eef2f7;
            margin: 0;
            padding: 0;
            color: #333;
        }
        header {
            background: linear-gradient(135deg, #4e4376, #2b5876);
            color: #fff;
            padding: 18px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            box-shadow: 0 3px 8px rgba(0,0,0,0.2);
        }
        header h1 {
            font-size: 20px;
            margin: 0;
        }
        .logout {
            background: #e74c3c;
            color: #fff;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 6px;
            transition: 0.3s;
        }
        .logout:hover {
            background: #c0392b;
        }
        .container {
            width: 95%;
            max-width: 1100px;
            margin: 40px auto;
            background: #fff;
            border-radius: 12px;
            padding: 25px 35px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        h2 {
            color: #2b5876;
            font-size: 22px;
            margin-bottom: 20px;
        }
        .search-bar {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 20px;
        }
        input[type="text"] {
            flex: 1;
            min-width: 220px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
        }
        button {
            background: #4e4376;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
            font-weight: 500;
        }
        button:hover {
            background: #2b5876;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 15px;
        }
        th, td {
            padding: 12px 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #4e4376;
            color: white;
            font-weight: 600;
        }
        tr:hover {
            background: #f9f9f9;
        }
        #loadMore {
            display: block;
            margin: 25px auto 0;
            background: #2b5876;
            color: #fff;
            border: none;
            padding: 10px 25px;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        #loadMore:hover {
            background: #4e4376;
        }
        @media (max-width: 700px) {
            header h1 {
                text-align: center;
                width: 100%;
                margin-bottom: 10px;
            }
            .container {
                padding: 20px;
            }
            table th, table td {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
<header>
    <h1>Welcome Coach <?= htmlspecialchars($_SESSION['username']); ?></h1>
    <a href="logout.php" class="logout">Logout</a>
</header>

<div class="container">
    <h2>🏅 Total Athletes: <?= $totalAthletes; ?></h2>

    <div class="search-bar">
        <input type="text" id="searchBox" placeholder="Search athlete by name...">
        <button id="searchBtn">Search</button>
    </div>

    <table id="athletesTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <button id="loadMore">Load More</button>
</div>

<script>
    let offset = 0;
    const limit = 5;

    // ✅ Load data asynchronously
    function loadAthletes(search = "") {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", `fetch_athletes.php?offset=${offset}&limit=${limit}&search=${encodeURIComponent(search)}`, true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                const tbody = document.querySelector("#athletesTable tbody");
                if (offset === 0) tbody.innerHTML = ""; // Reset when searching
                tbody.insertAdjacentHTML("beforeend", xhr.responseText);

                if (xhr.responseText.trim() === "") {
                    document.getElementById("loadMore").style.display = "none";
                } else {
                    document.getElementById("loadMore").style.display = "block";
                }
            }
        };
        xhr.send();
    }

    // ✅ Event listeners
    document.getElementById("loadMore").addEventListener("click", () => {
        offset += limit;
        loadAthletes(document.getElementById("searchBox").value);
    });

    document.getElementById("searchBtn").addEventListener("click", () => {
        offset = 0;
        loadAthletes(document.getElementById("searchBox").value);
    });

    // ✅ Initial load
    loadAthletes();
</script>
</body>
</html>
