<?php
require_once "db_connect.php"; // DB connection: $conn

class Registration {
    protected string $error = '';
    protected string $success = '';
    protected array $formData = [];

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    protected function validateInput(array $data): bool {
        $this->formData = $data;
        $requiredFields = ['username', 'email', 'password', 'confirm_password', 'role'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                $this->error = "All required fields must be filled.";
                return false;
            }
        }
        if (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $data['username'])) {
            $this->error = "Username must be 3-50 characters (letters, numbers, underscores only).";
            return false;
        }
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $this->error = "Invalid email address.";
            return false;
        }
        if (strlen($data['password']) < 8 || !preg_match('/[A-Za-z]/', $data['password']) || !preg_match('/[0-9]/', $data['password'])) {
            $this->error = "Password must be at least 8 characters and contain at least one letter and one number.";
            return false;
        }
        if ($data['password'] !== $data['confirm_password']) {
            $this->error = "Passwords do not match.";
            return false;
        }
        $validRoles = ['Administrator', 'Coach', 'Student'];
        if (!in_array($data['role'], $validRoles)) {
            $this->error = "Invalid role selected.";
            return false;
        }
        if (in_array($data['role'], ['Coach', 'Student']) && (empty($data['school_id']) || !is_numeric($data['school_id']))) {
            $this->error = "School selection is required for Coaches and Students.";
            return false;
        }
        return true;
    }

    protected function checkExistingUser($conn, string $username, string $email): bool {
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->error = "Username already exists. Please choose another.";
            $stmt->close();
            return false;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $this->error = "Email already registered. Please use another email.";
            $stmt->close();
            return false;
        }
        $stmt->close();
        return true;
    }

    public function register(array $data, $conn): bool {
        if (!$this->validateInput($data)) return false;
        if (!$this->checkExistingUser($conn, $data['username'], $data['email'])) return false;

        $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT);
        $schoolId = ($data['role'] === 'Administrator') ? null : (int)$data['school_id'];

        if ($schoolId === null) {
            $stmt = $conn->prepare("INSERT INTO users (username,email,password_hash,role,school_id,status) VALUES (?,?,?,?,NULL,'active')");
            $stmt->bind_param("ssss",$data['username'],$data['email'],$passwordHash,$data['role']);
        } else {
            $stmt = $conn->prepare("INSERT INTO users (username,email,password_hash,role,school_id,status) VALUES (?,?,?,?,?,'active')");
            $stmt->bind_param("ssssi",$data['username'],$data['email'],$passwordHash,$data['role'],$schoolId);
        }

        if ($stmt->execute()) {
            $this->success = "Registration successful! You can now <a href='login.php' style='color:#2E7D32; font-weight:bold;'>login</a>.";
            $stmt->close();
            return true;
        } else {
            $this->error = "Registration failed. Please try again.";
            $stmt->close();
            return false;
        }
    }

    public function getSchools($conn): array {
        $schools = [];
        $result = $conn->query("SELECT school_id, school_name FROM schools ORDER BY school_name ASC");
        while ($row = $result->fetch_assoc()) $schools[] = $row;
        return $schools;
    }

    protected function selectOption(string $current, string $value): string {
        return $current === $value ? 'selected' : '';
    }

    public function renderForm($conn): void {
        $schools = $this->getSchools($conn);
        $errorHtml = $this->error ? "<p class='error-msg'>{$this->error}</p>" : "";
        $successHtml = $this->success ? "<p class='success-msg'>{$this->success}</p>" : "";

        $username = htmlspecialchars($this->formData['username'] ?? '');
        $email = htmlspecialchars($this->formData['email'] ?? '');
        $selectedRole = $this->formData['role'] ?? '';
        $selectedSchool = $this->formData['school_id'] ?? '';

        echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sport App - Registration</title>
<style>
body{font-family:Arial,sans-serif;background:linear-gradient(135deg,#1b5e20,#43a047);display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;padding:20px}
.container{background:white;padding:30px;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,0.2);width:100%;max-width:450px}
h2{text-align:center;color:#1b5e20;margin-bottom:10px}
.subtitle{text-align:center;color:#666;margin-bottom:20px;font-size:14px}
.error-msg{background:#ffebee;color:#c62828;padding:10px;border-radius:6px;margin-bottom:15px}
.success-msg{background:#e8f5e9;color:#2e7d32;padding:10px;border-radius:6px;margin-bottom:15px}
.form-group{margin-bottom:15px}
label{font-weight:bold;display:block;margin-bottom:5px;color:#333}
label span{color:#c62828}
input,select{width:100%;padding:10px;border:1px solid #ccc;border-radius:6px;box-sizing:border-box;font-size:14px}
input:focus,select:focus{outline:none;border-color:#2E7D32}
button{width:100%;padding:12px;border:none;border-radius:6px;background:#2E7D32;color:white;font-weight:bold;cursor:pointer;font-size:16px}
button:hover{background:#43a047}
.login-link{text-align:center;margin-top:15px;font-size:14px}
.login-link a{color:#2E7D32;text-decoration:none;font-weight:bold}
.login-link a:hover{text-decoration:underline}
.school-group{display:none}
.school-group.show{display:block}
.help-text{font-size:12px;color:#666;margin-top:5px}
.password-wrapper{position:relative}
.toggle-eye{position:absolute;right:10px;top:10px;cursor:pointer;font-size:16px;color:#2E7D32}
</style>
</head>
<body>
<div class="container">
<h2>🏆 Sport App Registration</h2>
<p class="subtitle">Create your account</p>
{$errorHtml}
{$successHtml}
<form method="POST" id="registrationForm">
<div class="form-group">
<label>Username <span>*</span></label>
<input type="text" name="username" value="{$username}" required>
<p class="help-text">3-50 characters, letters, numbers and underscores only</p>
</div>
<div class="form-group">
<label>Email <span>*</span></label>
<input type="email" name="email" value="{$email}" required>
</div>
<div class="form-group password-wrapper">
<label>Password <span>*</span></label>
<input type="password" name="password" id="passwordField" required>
<span class="toggle-eye" id="togglePassword">👁️</span>
<p class="help-text">Minimum 8 characters, at least one letter and one number</p>
</div>
<div class="form-group password-wrapper">
<label>Confirm Password <span>*</span></label>
<input type="password" name="confirm_password" id="confirmPasswordField" required>
<span class="toggle-eye" id="toggleConfirmPassword">👁️</span>
</div>
<div class="form-group">
<label>Role <span>*</span></label>
<select name="role" id="roleSelect" required>
<option value="">Select Role</option>
<option value="Administrator" {$this->selectOption($selectedRole,'Administrator')}>Administrator</option>
<option value="Coach" {$this->selectOption($selectedRole,'Coach')}>Coach</option>
<option value="Student" {$this->selectOption($selectedRole,'Student')}>Student</option>
</select>
</div>
<div class="form-group school-group" id="schoolGroup">
<label>School <span>*</span></label>
<select name="school_id" id="schoolSelect">
<option value="">Select School</option>
HTML;

        foreach ($schools as $school) {
            $selected = ($selectedSchool == $school['school_id']) ? 'selected' : '';
            echo "<option value='{$school['school_id']}' {$selected}>{$school['school_name']}</option>\n";
        }

        echo <<<HTML
</select>
</div>
<button type="submit">Register</button>
</form>
<div class="login-link">
Already have an account? <a href="login.php">Login here</a>
</div>
</div>

<script>
// Show/hide school selection based on role
document.getElementById('roleSelect').addEventListener('change', function(){
const schoolGroup=document.getElementById('schoolGroup');
const schoolSelect=document.getElementById('schoolSelect');
if(this.value==='Coach'||this.value==='Student'){schoolGroup.classList.add('show');schoolSelect.setAttribute('required','required')}
else{schoolGroup.classList.remove('show');schoolSelect.removeAttribute('required');schoolSelect.value=''}
});
// Trigger on page load if role pre-selected
window.addEventListener('load',function(){
const roleSelect=document.getElementById('roleSelect');
if(roleSelect.value){roleSelect.dispatchEvent(new Event('change'))}
});

// Toggle password visibility
const passwordField=document.getElementById('passwordField');
const togglePassword=document.getElementById('togglePassword');
togglePassword.addEventListener('click',()=>{const type=passwordField.getAttribute('type')==='password'?'text':'password';passwordField.setAttribute('type',type);togglePassword.textContent=type==='password'?'👁️':'🙈';});

const confirmPasswordField=document.getElementById('confirmPasswordField');
const toggleConfirmPassword=document.getElementById('toggleConfirmPassword');
toggleConfirmPassword.addEventListener('click',()=>{const type=confirmPasswordField.getAttribute('type')==='password'?'text':'password';confirmPasswordField.setAttribute('type',type);toggleConfirmPassword.textContent=type==='password'?'👁️':'🙈';});
</script>
</body>
</html>
HTML;
    }
}

// Logic
$registration = new Registration();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $registration->register($_POST, $conn);
}
$registration->renderForm($conn);
