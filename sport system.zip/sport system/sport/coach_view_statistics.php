<?php
session_start();
if($_SESSION['role'] != 'Coach'){
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

$stats = $conn->query("
    SELECT ps.*, a.full_name, f.match_date
    FROM player_statistics ps
    JOIN athletes a ON ps.athlete_id = a.athlete_id
    JOIN results r ON ps.result_id = r.result_id
    JOIN fixtures f ON r.fixture_id = f.fixture_id
    WHERE a.school_id = {$_SESSION['school_id']}
    ORDER BY f.match_date DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Athlete Statistics</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
<h2>Athlete Performance Statistics</h2>
<?php if($stats->num_rows > 0): ?>
<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>Athlete</th>
    <th>Match Date</th>
    <th>Goals</th>
    <th>Assists</th>
    <th>Yellow Cards</th>
    <th>Red Cards</th>
    <th>Minutes Played</th>
    <th>Rating</th>
</tr>
</thead>
<tbody>
<?php while($row = $stats->fetch_assoc()): ?>
<tr>
    <td><?php echo $row['full_name']; ?></td>
    <td><?php echo $row['match_date']; ?></td>
    <td><?php echo $row['goals_scored']; ?></td>
    <td><?php echo $row['assists']; ?></td>
    <td><?php echo $row['yellow_cards']; ?></td>
    <td><?php echo $row['red_cards']; ?></td>
    <td><?php echo $row['minutes_played']; ?></td>
    <td><?php echo $row['performance_rating']; ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p class="alert alert-info">No statistics available yet.</p>
<?php endif; ?>
</div>
</body>
</html>
