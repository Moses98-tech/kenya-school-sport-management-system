<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

if(isset($_POST['add_competition'])){
    $name = $_POST['competition_name'];
    $sport_id = $_POST['sport_category_id'];
    $season = $_POST['season'];
    $start = $_POST['start_date'];
    $end = $_POST['end_date'];
    $status = $_POST['status'];
    $desc = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO competitions (competition_name,sport_category_id,season,start_date,end_date,status,description) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("sisssss",$name,$sport_id,$season,$start,$end,$status,$desc);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_competitions.php");
    exit;
}

$competitions = $conn->query("SELECT c.*, sc.sport_name FROM competitions c LEFT JOIN sport_categories sc ON c.sport_category_id = sc.sport_category_id ORDER BY c.start_date DESC");
$sports = $conn->query("SELECT * FROM sport_categories");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Competitions</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Manage Competitions</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<!-- Add Competition Form -->
<div class="card shadow mb-4">
  <div class="card-header bg-warning text-white">Add New Competition</div>
  <div class="card-body">
    <form method="POST">
      <div class="row g-2">
        <div class="col-md-4"><input type="text" name="competition_name" class="form-control" placeholder="Competition Name" required></div>
        <div class="col-md-4">
          <select name="sport_category_id" class="form-control" required>
            <option value="">Select Sport</option>
            <?php while($s = $sports->fetch_assoc()){ echo "<option value='{$s['sport_category_id']}'>{$s['sport_name']}</option>"; } ?>
          </select>
        </div>
        <div class="col-md-4"><input type="text" name="season" class="form-control" placeholder="Season (e.g., 2025 Spring)" required></div>
      </div>
      <div class="row g-2 mt-2">
        <div class="col-md-3"><input type="date" name="start_date" class="form-control" required></div>
        <div class="col-md-3"><input type="date" name="end_date" class="form-control" required></div>
        <div class="col-md-3">
          <select name="status" class="form-control" required>
            <option value="upcoming">Upcoming</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
          </select>
        </div>
        <div class="col-md-3"><input type="text" name="description" class="form-control" placeholder="Description"></div>
      </div>
      <button type="submit" name="add_competition" class="btn btn-warning mt-2">Add Competition</button>
    </form>
  </div>
</div>

<!-- Competitions Table -->
<div class="card shadow">
  <div class="card-header bg-warning text-white">Competitions</div>
  <div class="card-body table-responsive">
    <table class="table table-striped table-hover">
      <thead>
        <tr>
          <th>Name</th><th>Sport</th><th>Season</th><th>Start Date</th><th>End Date</th><th>Status</th><th>Description</th>
        </tr>
      </thead>
      <tbody>
        <?php while($c=$competitions->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($c['competition_name']) ?></td>
          <td><?= htmlspecialchars($c['sport_name'] ?? 'N/A') ?></td>
          <td><?= htmlspecialchars($c['season']) ?></td>
          <td><?= $c['start_date'] ?></td>
          <td><?= $c['end_date'] ?></td>
          <td><?= ucfirst($c['status']) ?></td>
          <td><?= htmlspecialchars($c['description']) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
</div>
</body>
</html>
