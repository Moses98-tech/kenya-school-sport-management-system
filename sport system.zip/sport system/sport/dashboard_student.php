<?php
session_start();
if ($_SESSION['role'] != 'Student') {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-info">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">🎽 Student Dashboard</a>
    <span class="text-white ms-auto">Hi, <?php echo $_SESSION['username']; ?></span>
    <a href="logout.php" class="btn btn-danger btn-sm ms-3">Logout</a>
  </div>
</nav>

<div class="container my-4">
  <div class="card shadow">
    <div class="card-header bg-info text-white">
      <h5>My Performance Overview</h5>
    </div>
    <div class="card-body">
      <p><strong>Sport:</strong> Football</p>
      <p><strong>Goals Scored:</strong> 8</p>
      <p><strong>Assists:</strong> 5</p>
      <p><strong>Cards:</strong> 1 Yellow, 0 Red</p>
    </div>
  </div>

  <div class="card mt-4 shadow">
    <div class="card-header bg-secondary text-white">
      <h5>Upcoming Fixtures</h5>
    </div>
    <div class="card-body">
      <p>🏫 Kiota High vs. Eastview Academy</p>
      <p>📅 15 Nov 2025 — 10:00 AM at Embakasi Stadium</p>
    </div>
  </div>
</div>

</body>
</html>
