<?php
session_start();
if ($_SESSION['role'] != 'Coach') {
    header("Location: login.php");
    exit;
}
require_once 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Coach Fixtures</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
  <h2>Upcoming Fixtures</h2>
  <a href="coach_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>Fixture ID</th>
        <th>Competition</th>
        <th>Home Team</th>
        <th>Away Team</th>
        <th>Date</th>
        <th>Time</th>
        <th>Venue</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $sql = "SELECT f.*, c.competition_name, s1.school_name AS home_team, s2.school_name AS away_team 
            FROM fixtures f 
            JOIN competitions c ON f.competition_id = c.competition_id
            JOIN schools s1 ON f.home_school_id = s1.school_id
            JOIN schools s2 ON f.away_school_id = s2.school_id
            WHERE f.home_school_id = ? OR f.away_school_id = ?
            ORDER BY f.match_date ASC, f.match_time ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $_SESSION['school_id'], $_SESSION['school_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['fixture_id']}</td>
            <td>{$row['competition_name']}</td>
            <td>{$row['home_team']}</td>
            <td>{$row['away_team']}</td>
            <td>{$row['match_date']}</td>
            <td>{$row['match_time']}</td>
            <td>{$row['venue']}</td>
            <td>{$row['status']}</td>
        </tr>";
    }
    ?>
    </tbody>
  </table>
</div>
</body>
</html>
