<?php
session_start();
if ($_SESSION['role'] != 'Coach') {
    header("Location: login.php");
    exit;
}
require_once 'db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>League Standings</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-4">
  <h2>League Standings</h2>
  <a href="coach_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>Position</th>
        <th>School</th>
        <th>MP</th>
        <th>W</th>
        <th>D</th>
        <th>L</th>
        <th>GF</th>
        <th>GA</th>
        <th>GD</th>
        <th>Points</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $sql = "SELECT s.*, sch.school_name FROM league_standings s
            JOIN schools sch ON s.school_id = sch.school_id
            WHERE s.competition_id IN (SELECT DISTINCT competition_id FROM fixtures WHERE home_school_id = ? OR away_school_id = ?)
            ORDER BY s.position ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $_SESSION['school_id'], $_SESSION['school_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['position']}</td>
            <td>{$row['school_name']}</td>
            <td>{$row['matches_played']}</td>
            <td>{$row['wins']}</td>
            <td>{$row['draws']}</td>
            <td>{$row['losses']}</td>
            <td>{$row['goals_for']}</td>
            <td>{$row['goals_against']}</td>
            <td>{$row['goal_difference']}</td>
            <td>{$row['total_points']}</td>
        </tr>";
    }
    ?>
    </tbody>
  </table>
</div>
</body>
</html>
