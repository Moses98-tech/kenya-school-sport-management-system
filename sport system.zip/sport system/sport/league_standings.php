<?php
require_once 'db_connect.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head><title>Player Statistics</title></head>
<body>
<h2>Player Statistics</h2>

<a href="admin_dashboard.php">← Back</a> | <a href="logout.php">Logout</a>
<hr>

<form method="POST" action="">
    <input type="text" name="athlete_id" placeholder="Athlete ID" required>
    <input type="text" name="matches_played" placeholder="Matches Played" required>
    <input type="text" name="goals" placeholder="Goals" required>
    <input type="text" name="assists" placeholder="Assists" required>
    <button type="submit" name="add">Add Stat</button>
</form>

<?php
if (isset($_POST['add'])) {
    $athlete_id = $_POST['athlete_id'];
    $matches = $_POST['matches_played'];
    $goals = $_POST['goals'];
    $assists = $_POST['assists'];

    $sql = "INSERT INTO player_statistics (athlete_id, matches_played, goals, assists) VALUES ('$athlete_id','$matches','$goals','$assists')";
    $conn->query($sql);
    echo "<p>Stats Added!</p>";
}

$result = $conn->query("SELECT * FROM player_statistics");
echo "<table border='1'><tr><th>ID</th><th>Athlete ID</th><th>Matches</th><th>Goals</th><th>Assists</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['athlete_id']}</td><td>{$row['matches_played']}</td><td>{$row['goals']}</td><td>{$row['assists']}</td></tr>";
}
echo "</table>";
?>
</body>
</html>
