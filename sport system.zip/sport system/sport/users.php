<?php
require_once 'db_connect.php';
require_once 'auth.php';
requireLogin();

// Only admin can manage users
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// CREATE / UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $school_id = $_POST['school_id'];
    $status = $_POST['status'] ?? 'active';

    if (!empty($_POST['user_id'])) {
        // Update
        $stmt = $conn->prepare("UPDATE users SET username=?, email=?, password_hash=?, role=?, school_id=?, status=? WHERE user_id=?");
        $stmt->bind_param("ssssisi", $username, $email, $password, $role, $school_id, $status, $_POST['user_id']);
        $stmt->execute();
        $stmt->close();
    } else {
        // Insert
        $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, role, school_id, status, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssssis", $username, $email, $password, $role, $school_id, $status);
        $stmt->execute();
        $stmt->close();
    }
}

// DELETE
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM users WHERE user_id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Fetch data
$users = $conn->query("SELECT u.*, s.school_name FROM users u LEFT JOIN schools s ON u.school_id=s.school_id");
$schools = $conn->query("SELECT * FROM schools");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2>Users Management</h2>
    <a href="admin_dashboard.php" class="btn btn-secondary mb-3">Back to Dashboard</a>
    <hr>

    <!-- Add/Edit Form -->
    <form method="POST" class="row g-3 mb-4">
        <input type="hidden" name="user_id" id="user_id">
        <div class="col-md-2"><input type="text" name="username" id="username" placeholder="Username" class="form-control" required></div>
        <div class="col-md-3"><input type="email" name="email" id="email" placeholder="Email" class="form-control" required></div>
        <div class="col-md-2"><input type="password" name="password" id="password" placeholder="Password" class="form-control" required></div>
        <div class="col-md-2">
            <select name="role" id="role" class="form-control" required>
                <option value="admin">Admin</option>
                <option value="coach">Coach</option>
                <option value="athlete">Athlete</option>
            </select>
        </div>
        <div class="col-md-2">
            <select name="school_id" id="school_id" class="form-control">
                <option value="">Select School</option>
                <?php while ($s = $schools->fetch_assoc()) echo "<option value='{$s['school_id']}'>{$s['school_name']}</option>"; ?>
            </select>
        </div>
        <div class="col-md-1"><button type="submit" class="btn btn-primary w-100">Save</button></div>
    </form>

    <!-- Users Table -->
    <table class="table table-striped">
        <thead class="table-dark">
            <tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>School</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php while ($u = $users->fetch_assoc()): ?>
            <tr>
                <td><?= $u['user_id'] ?></td>
                <td><?= htmlspecialchars($u['username']) ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td><?= $u['role'] ?></td>
                <td><?= $u['school_name'] ?></td>
                <td><?= $u['status'] ?></td>
                <td>
                    <a href="#" class="btn btn-warning btn-sm edit-btn"
                       data-id="<?= $u['user_id'] ?>"
                       data-username="<?= htmlspecialchars($u['username']) ?>"
                       data-email="<?= htmlspecialchars($u['email']) ?>"
                       data-role="<?= $u['role'] ?>"
                       data-school="<?= $u['school_id'] ?>"
                    >Edit</a>
                    <a href="?delete=<?= $u['user_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this user?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script>
document.querySelectorAll('.edit-btn').forEach(btn=>{
    btn.addEventListener('click',e=>{
        e.preventDefault();
        document.getElementById('user_id').value=btn.dataset.id;
        document.getElementById('username').value=btn.dataset.username;
        document.getElementById('email').value=btn.dataset.email;
        document.getElementById('role').value=btn.dataset.role;
        document.getElementById('school_id').value=btn.dataset.school;
    });
});
</script>
</body>
</html>
