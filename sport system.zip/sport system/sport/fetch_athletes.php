<?php
session_start();
require_once "db_connect.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Coach') {
    exit;
}

$schoolId = $_SESSION['school_id'];
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 5;
$search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : "%%";

$stmt = $conn->prepare("SELECT user_id, username, email, status 
                        FROM users 
                        WHERE school_id = ? AND role = 'Student' AND username LIKE ?
                        ORDER BY user_id ASC
                        LIMIT ?, ?");
$stmt->bind_param("isii", $schoolId, $search, $offset, $limit);
$stmt->execute();
$result = $stmt->get_result();

while ($athlete = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$athlete['user_id']}</td>
            <td>" . htmlspecialchars($athlete['username']) . "</td>
            <td>" . htmlspecialchars($athlete['email']) . "</td>
            <td>" . ucfirst($athlete['status']) . "</td>
          </tr>";
}
