<?php
session_start();
if ($_SESSION['role'] != 'Administrator') {
    header("Location: login.php");
    exit;
}
require_once "db_connect.php";

// Add Fixture
if(isset($_POST['add_fixture'])){
    $competition_id = $_POST['competition_id'];
    $home_school_id = $_POST['home_school_id'];
    $away_school_id = $_POST['away_school_id'];
    $match_date = $_POST['match_date'];
    $match_time = $_POST['match_time'];
    $venue = $_POST['venue'];
    $round = $_POST['round'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO fixtures (competition_id,home_school_id,away_school_id,match_date,match_time,venue,round,status) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->bind_param("iiisssss",$competition_id,$home_school_id,$away_school_id,$match_date,$match_time,$venue,$round,$status);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_fixtures.php");
    exit;
}

// Fetch competitions and schools
$competitions = $conn->query("SELECT * FROM competitions WHERE status='active'");
$schools = $conn->query("SELECT * FROM schools WHERE status='active'");
$fixtures = $conn->query("SELECT f.*, c.competition_name, hs.school_name AS home_team, asch.school_name AS away_team FROM fixtures f LEFT JOIN competitions c ON f.competition_id=c.competition_id LEFT JOIN schools hs ON f.home_school_id=hs.school_id LEFT JOIN schools asch ON f.away_school_id=asch.school_id ORDER BY f.match_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Fixtures</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
<h2>Manage Fixtures</h2>
<a href="admin_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

<!-- Add Fixture Form -->
<div class="card shadow mb-4">
<div class="card-header bg-info text-white">Add New Fixture</div>
<div class="card-body">
<form method="POST">
<div class="row g-2">
<div class="col-md-3">
<select name="competition_id" class="form-control" required>
<option value="">Select Competition</option>
<?php while($c=$competitions->fetch_assoc()){ echo "<option value='{$c['competition_id']}'>{$c['competition_name']}</option>"; } ?>
</select>
</div>
<div class="col-md-3">
<select name="home_school_id" class="form-control" required>
<option value="">Select Home School</option>
<?php while($s=$schools->fetch_assoc()){ echo "<option value='{$s['school_id']}'>{$s['school_name']}</option>"; } ?>
</select>
</div>
<div class="col-md-3">
<select name="away_school_id" class="form-control" required>
<option value="">Select Away School</option>
<?php
$schools->data_seek(0); // reset pointer
while($s=$schools->fetch_assoc()){ echo "<option value='{$s['school_id']}'>{$s['school_name']}</option>"; }
?>
</select>
</div>
<div class="col-md-3"><input type="date" name="match_date" class="form-control" required></div>
</div>
<div class="row g-2 mt-2">
<div class="col-md-3"><input type="time" name="match_time" class="form-control" required></div>
<div class="col-md-3"><input type="text" name="venue" class="form-control" placeholder="Venue"></div>
<div class="col-md-3"><input type="text" name="round" class="form-control" placeholder="Round"></div>
<div class="col-md-3">
<select name="status" class="form-control">
<option value="scheduled" selected>Scheduled</option>
<option value="completed">Completed</option>
<option value="postponed">Postponed</option>
<option value="inplay">In Play</option>
</select>
</div>
</div>
<button type="submit" name="add_fixture" class="btn btn-info mt-2">Add Fixture</button>
</form>
</div>
</div>

<!-- Fixtures Table -->
<div class="card shadow">
<div class="card-header bg-info text-white">All Fixtures</div>
<div class="card-body table-responsive">
<table class="table table-striped table-hover">
<thead>
<tr>
<th>Competition</th><th>Home</th><th>Away</th><th>Date</th><th>Time</th><th>Venue</th><th>Round</th><th>Status</th>
</tr>
</thead>
<tbody>
<?php while($f=$fixtures->fetch_assoc()): ?>
<tr>
<td><?= htmlspecialchars($f['competition_name']) ?></td>
<td><?= htmlspecialchars($f['home_team']) ?></td>
<td><?= htmlspecialchars($f['away_team']) ?></td>
<td><?= $f['match_date'] ?></td>
<td><?= $f['match_time'] ?></td>
<td><?= htmlspecialchars($f['venue']) ?></td>
<td><?= htmlspecialchars($f['round']) ?></td>
<td><?= ucfirst($f['status']) ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</body>
</html>
